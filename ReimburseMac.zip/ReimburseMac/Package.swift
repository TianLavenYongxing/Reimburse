// swift-tools-version: 5.9
import PackageDescription
let package = Package(
    name: "ReimburseMac",
    platforms: [.macOS(.v13)],
    products: [.executable(name: "ReimburseMac", targets: ["ReimburseMac"])],
    dependencies: [.package(url: "https://github.com/groue/GRDB.swift.git", exact: "6.29.3")],
    targets: [
        .target(name: "ReimburseCore", dependencies: [.product(name: "GRDB", package: "GRDB.swift")]),
        .executableTarget(name: "ReimburseMac", dependencies: ["ReimburseCore"]),
        .testTarget(name: "ReimburseCoreTests", dependencies: ["ReimburseCore"])
    ]
)
