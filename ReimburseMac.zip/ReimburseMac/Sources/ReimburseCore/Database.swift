import Foundation
import GRDB

public final class AppDatabase {
    private let queue: DatabaseQueue
    public let url: URL?
    public init(url: URL? = nil) throws {
        self.url = url
        if let url {
            try FileManager.default.createDirectory(at: url.deletingLastPathComponent(), withIntermediateDirectories: true)
            queue = try DatabaseQueue(path: url.path)
        } else { queue = try DatabaseQueue() }
        var migrator = DatabaseMigrator()
        migrator.registerMigration("initial_schema") { db in
            try db.execute(sql: """
                CREATE TABLE reimbursement (
                    id TEXT PRIMARY KEY NOT NULL,
                    location TEXT NOT NULL, start DOUBLE NOT NULL, end DOUBLE NOT NULL,
                    sent BOOLEAN NOT NULL DEFAULT 0, note TEXT NOT NULL DEFAULT ''
                );
                CREATE TABLE document (
                    id TEXT PRIMARY KEY NOT NULL,
                    reimbursementID TEXT NOT NULL REFERENCES reimbursement(id) ON DELETE CASCADE,
                    kind TEXT NOT NULL, customType TEXT NOT NULL DEFAULT '', number TEXT NOT NULL DEFAULT '',
                    expected INTEGER NOT NULL CHECK(expected >= 0),
                    actual INTEGER NOT NULL CHECK(actual >= 0),
                    note TEXT NOT NULL DEFAULT '', manualAmount BOOLEAN NOT NULL DEFAULT 0,
                    position INTEGER NOT NULL
                );
                CREATE INDEX document_parent ON document(reimbursementID, position);
                """)
        }
        try migrator.migrate(queue)
    }
    public static func live() throws -> AppDatabase {
        let base = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        return try AppDatabase(url: base.appendingPathComponent("ReimbursementRecords/records.sqlite"))
    }
    public func fetch() throws -> [Trip] {
        try queue.read { db in
            let documents = try Row.fetchAll(db, sql: "SELECT * FROM document ORDER BY position, id")
            let grouped = Dictionary(grouping: documents) { (row: Row) -> String in row["reimbursementID"] }
            return try Row.fetchAll(db, sql: "SELECT * FROM reimbursement ORDER BY start DESC, location, id").map { row in
                var trip = Trip()
                trip.id = row["id"]; trip.location = row["location"]
                trip.start = Date(timeIntervalSince1970: row["start"])
                trip.end = Date(timeIntervalSince1970: row["end"])
                trip.sent = row["sent"]; trip.note = row["note"]
                trip.bills = try (grouped[trip.id] ?? []).map { row in
                    guard let kind = BillKind(rawValue: row["kind"]) else { throw RuleError("无法识别数据库中的单据类型。") }
                    var bill = Bill(kind: kind)
                    bill.id = row["id"]; bill.customType = row["customType"]; bill.number = row["number"]
                    bill.expected = row["expected"]; bill.actual = row["actual"]
                    bill.note = row["note"]; bill.manualAmount = row["manualAmount"]
                    return bill
                }
                return trip
            }
        }
    }
    public func save(_ trip: Trip) throws {
        try trip.validate()
        // Aggregate save: parent plus all documents form one transaction.
        try queue.write { db in
            try db.execute(sql: """
                INSERT INTO reimbursement(id,location,start,end,sent,note) VALUES(?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET location=excluded.location,start=excluded.start,
                    end=excluded.end,sent=excluded.sent,note=excluded.note
                """, arguments: [trip.id,trip.location,trip.start.timeIntervalSince1970,trip.end.timeIntervalSince1970,trip.sent,trip.note])
            try db.execute(sql: "DELETE FROM document WHERE reimbursementID=?", arguments: [trip.id])
            for (position, bill) in trip.bills.enumerated() {
                try db.execute(sql: """
                    INSERT INTO document(id,reimbursementID,kind,customType,number,expected,actual,note,manualAmount,position)
                    VALUES(?,?,?,?,?,?,?,?,?,?)
                    """, arguments: [bill.id,trip.id,bill.kind.rawValue,bill.customType,bill.number,bill.expected,bill.actual,bill.note,bill.manualAmount,position])
            }
        }
    }
    public func delete(_ id: String) throws {
        try queue.write { db in
            try db.execute(sql: "DELETE FROM reimbursement WHERE id=?", arguments: [id])
        }
    }
    public func backup(to url: URL) throws {
        let destination = try DatabaseQueue(path: url.path)
        try queue.backup(to: destination)
    }
}
