import SwiftUI
import AppKit
import ReimburseCore

@MainActor
final class Store: ObservableObject {
    @Published var trips: [Trip] = []
    @Published var error: String?
    let database: AppDatabase?
    init() {
        do { database = try AppDatabase.live() }
        catch { database = nil; self.error = "数据库无法打开：\(error.localizedDescription)" }
        reload()
    }
    func reload() {
        guard let database else { return }
        do { trips = try database.fetch() } catch { self.error = error.localizedDescription }
    }
    func save(_ trip: Trip) throws {
        guard let database else { throw RuleError("数据库未打开，无法保存。") }
        try database.save(trip); reload()
    }
    func delete(_ trip: Trip) throws {
        guard let database else { throw RuleError("数据库未打开。") }
        try database.delete(trip.id); reload()
    }
    func backup() {
        let panel = NSSavePanel()
        panel.title = "备份报销数据库"
        panel.nameFieldStringValue = "报销备份-\(Date().formatted(.iso8601.year().month().day().dateSeparator(.dash))).sqlite"
        guard panel.runModal() == .OK, let url = panel.url, let database else { return }
        guard url.standardizedFileURL != database.url?.standardizedFileURL else {
            error = "请选择其他备份位置，不能覆盖正在使用的数据库。"; return
        }
        do { try database.backup(to: url); NSWorkspace.shared.activateFileViewerSelecting([url]) }
        catch { self.error = "备份失败：\(error.localizedDescription)" }
    }
}

@main
struct ReimburseApp: App {
    @StateObject private var store = Store()
    var body: some Scene {
        WindowGroup("报销记录") {
            ContentView().environmentObject(store)
                .frame(minWidth: 1180, minHeight: 700)
                .preferredColorScheme(.light)
                .tint(.blue)
                .onAppear { NSApplication.shared.setActivationPolicy(.regular); NSApplication.shared.activate(ignoringOtherApps: true) }
        }
        .defaultSize(width: 1320, height: 840)
        .commands {
            CommandGroup(replacing: .newItem) {}
            CommandGroup(after: .saveItem) {
                Button("备份数据库…") { store.backup() }.keyboardShortcut("b", modifiers: [.command, .shift])
                Button("打开数据文件夹") {
                    if let url = store.database?.url { NSWorkspace.shared.activateFileViewerSelecting([url]) }
                }
            }
        }
    }
}

extension BillStatus {
    var color: Color {
        switch self { case .waiting: return .orange; case .partial: return .purple; case .paid: return .green }
    }
}
func dateText(_ date: Date) -> String { date.formatted(.dateTime.year().month(.twoDigits).day(.twoDigits)) }

