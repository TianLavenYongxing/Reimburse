import SwiftUI
import ReimburseCore

// 编辑时保留金额文本，保存时再转换为整数分。
struct BillDraft: Identifiable, Equatable {
    var id: String
    var kind: BillKind
    var customType: String
    var number: String
    var expected: String
    var actual: String
    var note: String
    var manualAmount: Bool

    init(_ bill: Bill, blankExpected: Bool = false) {
        id = bill.id
        kind = bill.kind
        customType = bill.customType
        number = bill.number
        expected = blankExpected ? "" : Money.plain(bill.expected)
        actual = Money.plain(bill.actual)
        note = bill.note
        manualAmount = bill.manualAmount
    }

    func value() throws -> Bill {
        var bill = Bill(kind: kind)

        bill.id = id
        bill.customType = customType.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        bill.number = number.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        bill.expected = try Money.parse(expected)
        bill.actual = try Money.parse(actual)
        bill.note = note
        bill.manualAmount = manualAmount

        try bill.validate()
        return bill
    }
}

struct TripEditor: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) private var dismiss

    let isNew: Bool

    private let original: Trip
    private let initialBills: [BillDraft]

    @State private var trip: Trip
    @State private var bills: [BillDraft]
    @State private var showNote = false
    @State private var error: String?
    @State private var discard = false
    @State private var deleting: String?

    init(trip: Trip, isNew: Bool = false) {
        self.isNew = isNew
        original = trip

        var draft = trip

        if isNew {
            draft.updateAutomaticAllowances()
        }

        let documents = draft.bills.map {
            BillDraft(
                $0,
                blankExpected: isNew && $0.kind != .allowance
            )
        }

        initialBills = documents
        _trip = State(initialValue: draft)
        _bills = State(initialValue: documents)
    }

    private var dirty: Bool {
        trip.location != original.location
            || trip.start != original.start
            || trip.end != original.end
            || trip.sent != original.sent
            || trip.note != original.note
            || bills != initialBills
    }

    var body: some View {
        VStack(spacing: 0) {
            header

            Divider()

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    parentForm

                    documentsHeader

                    documentsGrid

                    if bills.isEmpty {
                        Text("请点击“添加单据”，至少关联一张单据后保存。")
                            .foregroundColor(.secondary)
                            .frame(maxWidth: .infinity)
                            .padding(25)
                    }

                    Text(
                        "到账金额填写累计实收；状态自动计算。补贴默认按天计算，手动修改后不再随日期变化。"
                    )
                    .font(.caption)
                    .foregroundColor(.secondary)
                }
                .padding(22)
            }
            .background(LedgerStyle.canvas)
        }
        .frame(width: 1060, height: 740)
        .background(Color.white)
        .onChange(of: trip.start) { _ in
            syncAllowance()
        }
        .onChange(of: trip.end) { _ in
            syncAllowance()
        }
        .interactiveDismissDisabled(dirty)
        .alert(
            "请检查填写内容",
            isPresented: Binding(
                get: { error != nil },
                set: {
                    if !$0 {
                        error = nil
                    }
                }
            )
        ) {
            Button("知道了") {
                error = nil
            }
        } message: {
            Text(error ?? "")
        }
        .alert("放弃未保存的修改？", isPresented: $discard) {
            Button("继续编辑", role: .cancel) {}

            Button("放弃修改", role: .destructive) {
                dismiss()
            }
        }
        .alert(
            "移除这张单据？",
            isPresented: Binding(
                get: { deleting != nil },
                set: {
                    if !$0 {
                        deleting = nil
                    }
                }
            )
        ) {
            Button("取消", role: .cancel) {
                deleting = nil
            }

            Button("移除", role: .destructive) {
                if let id = deleting {
                    bills.removeAll { $0.id == id }
                }
                deleting = nil
            }
        } message: {
            Text("点击“保存记录”后生效，取消编辑可放弃此次移除。")
        }
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 5) {
                Text(isNew ? "新增报销记录" : "编辑报销记录")
                    .font(.title2.bold())

                Text("填写报销信息，关联本次需要跟进的单据。")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }

            Spacer()

            Button("取消") {
                if dirty {
                    discard = true
                } else {
                    dismiss()
                }
            }
            .keyboardShortcut(.cancelAction)

            Button("保存记录") {
                save()
            }
            .buttonStyle(.borderedProminent)
            .keyboardShortcut("s", modifiers: .command)
        }
        .padding(22)
    }

    private var documentsHeader: some View {
        HStack {
            Text("关联单据")
                .font(.headline)

            Text("\(bills.count) 张")
                .font(.caption)
                .foregroundColor(.secondary)

            Spacer()

            Menu {
                ForEach(BillKind.allCases, id: \.self) { kind in
                    Button(kind.rawValue) {
                        add(kind)
                    }
                }
            } label: {
                Label("添加单据", systemImage: "plus")
            }
            .fixedSize()
        }
    }

    // 每行两张，行高由较高的卡片决定。
    private var documentsGrid: some View {
        VStack(spacing: 16) {
            ForEach(
                Array(stride(from: 0, to: bills.count, by: 2)),
                id: \.self
            ) { rowStart in
                HStack(alignment: .top, spacing: 16) {
                    ForEach(
                        rowStart..<min(rowStart + 2, bills.count),
                        id: \.self
                    ) { index in
                        let billID = bills[index].id

                        DocumentForm(
                            bill: $bills[index],
                            days: trip.dayCount,
                            sent: trip.sent
                        ) {
                            deleting = billID
                        }
                        .id(billID)
                        .frame(maxWidth: .infinity)
                    }

                    // 最后一行只有一张时，仍保持半行宽度。
                    if rowStart + 1 >= bills.count {
                        Color.clear
                            .frame(maxWidth: .infinity)
                    }
                }
                .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private var parentForm: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("报销信息")
                .font(.headline)

            HStack(alignment: .bottom, spacing: 18) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("地点 *")
                        .font(.caption)
                        .foregroundColor(.secondary)

                    TextField("例如：成都", text: $trip.location)
                        .textFieldStyle(.roundedBorder)
                }
                .frame(maxWidth: .infinity)

                DatePicker(
                    "开始日期",
                    selection: $trip.start,
                    displayedComponents: .date
                )

                DatePicker(
                    "结束日期",
                    selection: $trip.end,
                    displayedComponents: .date
                )

                Toggle("已寄出", isOn: $trip.sent)
                    .toggleStyle(.switch)
                    .fixedSize()
            }

            HStack {
                Text("共 \(trip.dayCount) 天 · 含首尾日期")
                    .font(.caption)
                    .foregroundColor(.secondary)

                Spacer()

                Text(
                    trip.sent
                        ? "所有关联单据统一标记为已寄出"
                        : "尚未寄出，单号可暂留空"
                )
                .font(.caption)
                .foregroundColor(.secondary)
            }

            DisclosureGroup(
                trip.note.isEmpty ? "添加备注（选填）" : "备注（已有内容）",
                isExpanded: $showNote
            ) {
                TextField("报销信息备注", text: $trip.note)
                    .textFieldStyle(.roundedBorder)
                    .padding(.top, 8)
            }
            .font(.caption)
        }
        .padding(18)
        .background(
            Color.white,
            in: RoundedRectangle(cornerRadius: 12)
        )
    }

    private func add(_ kind: BillKind) {
        var bill = Bill(kind: kind)

        if kind == .allowance {
            bill.expected = trip.calculatedAllowance
        }

        bills.append(
            BillDraft(
                bill,
                blankExpected: kind != .allowance
            )
        )
    }

    private func syncAllowance() {
        for index in bills.indices
        where bills[index].kind == .allowance
            && !bills[index].manualAmount {
            bills[index].expected = Money.plain(
                trip.calculatedAllowance
            )
        }
    }

    private func save() {
        do {
            var record = trip

            record.location = record.location.trimmingCharacters(
                in: .whitespacesAndNewlines
            )

            record.bills = try bills.enumerated().map { index, draft in
                do {
                    var updated = draft

                    if updated.kind == .allowance
                        && !updated.manualAmount {
                        updated.expected = Money.plain(
                            trip.calculatedAllowance
                        )
                    }

                    return try updated.value()
                } catch {
                    throw RuleError(
                        "第 \(index + 1) 张单据：\(error.localizedDescription)"
                    )
                }
            }

            try store.save(record)
            dismiss()
        } catch {
            self.error = error.localizedDescription
        }
    }
}

struct DocumentForm: View {
    @Binding var bill: BillDraft

    let days: Int
    let sent: Bool
    let remove: () -> Void

    @State private var showNote = false

    var body: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Label("单据", systemImage: "doc.text")
                    .font(.headline)

                Spacer()

                if let value = try? bill.value() {
                    StatusPill(
                        text: value.status.rawValue,
                        color: value.status.color
                    )
                }

                Button(role: .destructive, action: remove) {
                    Image(systemName: "trash")
                }
                .buttonStyle(.plain)
                .help("移除单据")
            }

            Picker("单据类型", selection: $bill.kind) {
                ForEach(BillKind.allCases, id: \.self) { kind in
                    Text(kind.rawValue)
                        .tag(kind)
                }
            }
            .onChange(of: bill.kind) { kind in
                if kind == .allowance && !bill.manualAmount {
                    bill.expected = Money.plain(
                        Int64(days) * 10_000
                    )
                }
            }

            if bill.kind == .other {
                field(
                    "自定义类型 *",
                    "例如：采购报销单",
                    $bill.customType
                )
            }

            field(
                sent ? "单号 *" : "单号（寄出前可为空）",
                "例如：xx01",
                $bill.number
            )

            HStack(alignment: .top, spacing: 16) {
                field(
                    "应收金额（元）*",
                    "0.00",
                    Binding(
                        get: { bill.expected },
                        set: {
                            bill.expected = $0

                            if bill.kind == .allowance {
                                bill.manualAmount = true
                            }
                        }
                    )
                )

                field(
                    "到账金额（元）*",
                    "0.00",
                    $bill.actual
                )
            }

            if bill.kind == .allowance {
                HStack {
                    Text(
                        bill.manualAmount
                            ? "手动金额 · 修改日期不会覆盖"
                            : "\(days) 天 × 100 元 / 天"
                    )
                    .font(.caption)
                    .foregroundColor(.secondary)

                    Spacer()

                    if bill.manualAmount {
                        Button("恢复自动") {
                            bill.manualAmount = false
                            bill.expected = Money.plain(
                                Int64(days) * 10_000
                            )
                        }
                        .font(.caption)
                    }
                }
            }

            DisclosureGroup(
                bill.note.isEmpty
                    ? "添加单据备注（选填）"
                    : "单据备注（已有内容）",
                isExpanded: $showNote
            ) {
                TextField(
                    "例如：火车、差旅补贴",
                    text: $bill.note
                )
                .textFieldStyle(.roundedBorder)
                .padding(.top, 8)
            }
            .font(.caption)
        }
        .padding(18)
        // 在绘制背景之前填满行高，让卡片边框等高。
        .frame(
            maxWidth: .infinity,
            maxHeight: .infinity,
            alignment: .topLeading
        )
        .background(
            Color.white,
            in: RoundedRectangle(cornerRadius: 12)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .strokeBorder(
                    LedgerStyle.border,
                    lineWidth: 1
                )
        )
    }

    private func field(
        _ label: String,
        _ placeholder: String,
        _ text: Binding<String>
    ) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label)
                .font(.caption)
                .foregroundColor(.secondary)

            TextField(placeholder, text: text)
                .textFieldStyle(.roundedBorder)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}
