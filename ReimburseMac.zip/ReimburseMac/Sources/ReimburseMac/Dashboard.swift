import SwiftUI
import ReimburseCore

enum LedgerStyle {
    static let canvas = Color(red: 0.962, green: 0.963, blue: 0.975)
    static let border = Color(red: 0.90, green: 0.91, blue: 0.94)
    static let ink = Color(red: 0.12, green: 0.13, blue: 0.16)
}

func uiMoney(_ cents: Int64) -> String {
    let formatter = NumberFormatter()
    formatter.locale = Locale(identifier: "en_US")
    formatter.numberStyle = .decimal
    formatter.minimumFractionDigits = 0
    formatter.maximumFractionDigits = 2

    let value = NSDecimalNumber(
        mantissa: UInt64(max(0, cents)),
        exponent: -2,
        isNegative: false
    )

    return "¥" + (formatter.string(from: value) ?? Money.plain(cents))
}

func shortDate(_ date: Date) -> String {
    let formatter = DateFormatter()
    formatter.dateFormat = "MM.dd"
    return formatter.string(from: date)
}

func fullDate(_ date: Date) -> String {
    let formatter = DateFormatter()
    formatter.dateFormat = "yyyy.MM.dd"
    return formatter.string(from: date)
}

struct StatusPill: View {
    let text: String
    let color: Color

    var body: some View {
        Text(text)
            .font(.system(size: 11, weight: .medium))
            .foregroundColor(color)
            .padding(.horizontal, 10)
            .padding(.vertical, 5)
            .background(color.opacity(0.09), in: Capsule())
    }
}

struct MonthGroup: Identifiable {
    let id: Date
    let trips: [Trip]

    var title: String {
        let components = Calendar.current.dateComponents(
            [.year, .month],
            from: id
        )

        return "\(components.year ?? 0)年\(components.month ?? 0)月"
    }
}

struct ContentView: View {
    @EnvironmentObject var store: Store

    @State private var filter: TripFilter = .all
    @State private var search = ""
    @State private var creating = false
    @State private var selected: Trip?

    var visible: [Trip] {
        store.trips.filter { trip in
            let numbers = trip.bills.map(\.number).joined(separator: " ")
            let searchText = "\(trip.name) \(trip.location) \(numbers)"

            return filter.matches(trip)
                && (
                    search.isEmpty
                    || searchText.localizedCaseInsensitiveContains(search)
                )
        }
    }

    var groups: [MonthGroup] {
        let calendar = Calendar.current

        let grouped = Dictionary(grouping: visible) { trip in
            calendar.date(
                from: calendar.dateComponents(
                    [.year, .month],
                    from: trip.start
                )
            ) ?? trip.start
        }

        return grouped.keys.sorted(by: >).map {
            MonthGroup(id: $0, trips: grouped[$0] ?? [])
        }
    }

    var pendingAmount: Int64 {
        visible
            .filter { !$0.sent }
            .reduce(0) { $0 + $1.expected }
    }

    var body: some View {
        VStack(spacing: 0) {
            header
            Divider()

            VStack(alignment: .leading, spacing: 22) {
                summary
                filters

                if visible.isEmpty {
                    emptyState
                } else {
                    ScrollView {
                        LazyVStack(alignment: .leading, spacing: 26) {
                            ForEach(groups) { group in
                                monthSection(group)
                            }
                        }
                        .padding(.bottom, 20)
                        .padding(.horizontal, 2)
                    }
                }
            }
            .padding(24)
            .frame(
                maxWidth: .infinity,
                maxHeight: .infinity,
                alignment: .topLeading
            )
            .background(LedgerStyle.canvas)
        }
        .foregroundColor(LedgerStyle.ink)
        .sheet(isPresented: $creating) {
            TripEditor(trip: Trip(), isNew: true)
                .environmentObject(store)
        }
        .sheet(item: $selected) { trip in
            TripDetail(trip: trip)
                .environmentObject(store)
        }
        .alert(
            "操作未完成",
            isPresented: Binding(
                get: { store.error != nil },
                set: {
                    if !$0 {
                        store.error = nil
                    }
                }
            )
        ) {
            Button("知道了") {
                store.error = nil
            }
        } message: {
            Text(store.error ?? "")
        }
    }

    private var header: some View {
        HStack(spacing: 18) {
            Text("报销记录")
                .font(.system(size: 16, weight: .semibold))

            Spacer()

            HStack(spacing: 7) {
                Image(systemName: "magnifyingglass")
                    .foregroundColor(.secondary)

                TextField("搜索名称、地点或单据号", text: $search)
                    .textFieldStyle(.plain)

                if !search.isEmpty {
                    Button {
                        search = ""
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.secondary)
                    }
                    .buttonStyle(.plain)
                }
            }
            .font(.system(size: 12))
            .padding(8)
            .frame(width: 230)
            .background(
                LedgerStyle.canvas,
                in: RoundedRectangle(cornerRadius: 7)
            )

            Button {
                store.backup()
            } label: {
                Image(systemName: "externaldrive")
            }
            .buttonStyle(.plain)
            .help("备份数据库")

            Button {
                creating = true
            } label: {
                HStack(spacing: 8) {
                    Text("新增报销记录")
                    Image(systemName: "plus")
                }
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .keyboardShortcut("n")
            .disabled(store.database == nil)
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 14)
        .background(Color.white)
    }

    private var summary: some View {
        let totals = Summary(visible)
        let documentCount = visible.reduce(0) { $0 + $1.bills.count }

        let rate = totals.expected > 0
            ? String(
                format: "%.1f%%",
                Double(totals.actual) / Double(totals.expected) * 100
            )
            : "—"

        return HStack(spacing: 16) {
            SummaryTile(
                title: "应收总金额",
                amount: totals.expected,
                subtitle: "\(documentCount) 份单据 · 未寄出应收 \(uiMoney(pendingAmount))",
                icon: "creditcard",
                color: LedgerStyle.ink
            )

            SummaryTile(
                title: "已到账金额",
                amount: totals.actual,
                subtitle: "到账率 \(rate)",
                icon: "arrow.down.circle",
                color: Color(red: 0, green: 0.69, blue: 0.45)
            )

            SummaryTile(
                title: "未到账金额",
                amount: totals.outstanding,
                subtitle: "未寄出应收 \(uiMoney(pendingAmount))",
                icon: "hourglass",
                color: .orange,
                amountColor: LedgerStyle.ink
            )
        }
    }

    private var filters: some View {
        HStack(spacing: 8) {
            ForEach(TripFilter.allCases) { item in
                Button {
                    filter = item
                } label: {
                    HStack(spacing: 5) {
                        if item != .all {
                            Circle()
                                .fill(
                                    filter == item
                                        ? Color.white
                                        : filterColor(item)
                                )
                                .frame(width: 5, height: 5)
                        }

                        Text(item == .all ? "全部" : item.rawValue)
                    }
                    .font(.system(size: 12))
                    .padding(.horizontal, 12)
                    .padding(.vertical, 7)
                    .foregroundColor(
                        filter == item ? .white : LedgerStyle.ink
                    )
                    .background(
                        filter == item ? Color.blue : Color.white,
                        in: Capsule()
                    )
                    .overlay(
                        Capsule()
                            .strokeBorder(
                                filter == item
                                    ? Color.clear
                                    : LedgerStyle.border,
                                lineWidth: 0.7
                            )
                    )
                }
                .buttonStyle(.plain)
            }

            Spacer(minLength: 8)

            Text("共 \(visible.count) 条报销记录")
                .font(.system(size: 11))
                .foregroundColor(.secondary)
        }
    }

    private func filterColor(_ value: TripFilter) -> Color {
        if value == .allPaid {
            return .green
        }

        if value == .unsent {
            return .gray
        }

        return BillStatus(rawValue: value.rawValue)?.color ?? .blue
    }

    private func monthSection(_ group: MonthGroup) -> some View {
        let settled = group.trips.allSatisfy(\.allPaid)

        return VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 9) {
                Text(group.title)
                    .font(.system(size: 14, weight: .semibold))

                Text(
                    "\(group.trips.count) 条记录 · 应收 \(uiMoney(Summary(group.trips).expected))\(settled ? " · 已全部到账" : "")"
                )
                .font(.system(size: 11))
                .foregroundColor(settled ? .green : .secondary)
            }

            LazyVGrid(
                columns: Array(
                    repeating: GridItem(
                        .flexible(minimum: 0),
                        spacing: 16,
                        alignment: .top
                    ),
                    count: 4
                ),
                alignment: .leading,
                spacing: 16
            ) {
                ForEach(group.trips) { trip in
                    Button {
                        selected = trip
                    } label: {
                        TripCard(trip: trip)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("\(trip.name)，查看单据详情")
                }
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 14) {
            Image(systemName: "doc.text.magnifyingglass")
                .font(.system(size: 38))
                .foregroundColor(.gray.opacity(0.6))

            Text(
                store.trips.isEmpty
                    ? "还没有报销记录"
                    : "没有符合条件的记录"
            )
            .font(.headline)

            Text(
                store.trips.isEmpty
                    ? "新增一条报销信息，关联需要跟进的单据。"
                    : "试试其他状态，或清空搜索条件。"
            )
            .font(.subheadline)
            .foregroundColor(.secondary)

            if store.trips.isEmpty {
                Button("新增报销记录") {
                    creating = true
                }
                .buttonStyle(.borderedProminent)
                .disabled(store.database == nil)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct SummaryTile: View {
    let title: String
    let amount: Int64
    let subtitle: String
    let icon: String
    let color: Color

    var amountColor: Color? = nil

    var body: some View {
        HStack(spacing: 15) {
            Image(systemName: icon)
                .font(.system(size: 18))
                .foregroundColor(color)
                .frame(width: 42, height: 42)
                .background(
                    color.opacity(0.08),
                    in: RoundedRectangle(cornerRadius: 11)
                )

            VStack(alignment: .leading, spacing: 5) {
                Text(title)
                    .font(.system(size: 12))
                    .foregroundColor(.secondary)

                Text(uiMoney(amount))
                    .font(
                        .system(
                            size: 28,
                            weight: .semibold,
                            design: .rounded
                        )
                    )
                    .foregroundColor(amountColor ?? color)
                    .monospacedDigit()
                    .lineLimit(1)
                    .minimumScaleFactor(0.6)

                Text(subtitle)
                    .font(.system(size: 10))
                    .foregroundColor(.secondary)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
            }

            Spacer(minLength: 0)
        }
        .padding(20)
        .frame(
            maxWidth: .infinity,
            minHeight: 112,
            alignment: .leading
        )
        .background(
            Color.white,
            in: RoundedRectangle(cornerRadius: 12)
        )
    }
}

struct TripCard: View {
    let trip: Trip

    @State private var hovered = false

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(trip.location)
                    .font(.system(size: 17, weight: .semibold))
                    .lineLimit(1)

                Spacer(minLength: 5)

                StatusPill(
                    text: trip.sent ? "已寄出" : "未寄出",
                    color: trip.sent ? .blue : .gray
                )
            }

            Text(trip.dateRange)
                .font(.system(size: 11))
                .foregroundColor(.secondary)
                .lineLimit(1)
                .minimumScaleFactor(0.8)

            HStack {
                Label(
                    "\(trip.bills.count) 张单据",
                    systemImage: "doc.on.doc"
                )
                .font(.system(size: 11))
                .foregroundColor(.secondary)

                Spacer()

                if trip.allPaid {
                    Text("全部到账")
                        .font(.system(size: 10, weight: .medium))
                        .foregroundColor(.green)
                }
            }

            Divider()
                .opacity(0.5)

            VStack(spacing: 13) {
                ForEach(Array(trip.sortedBills.prefix(2))) { bill in
                    cardBill(bill)
                }

                if trip.bills.count == 1 {
                    Color.clear.frame(height: 43)
                }
            }

            HStack {
                Text(
                    trip.bills.count > 2
                        ? "另有 \(trip.bills.count - 2) 张 · 查看详情"
                        : "查看详情"
                )

                Spacer()

                Image(systemName: "arrow.up.right")
            }
            .font(.system(size: 10))
            .foregroundColor(.secondary)
        }
        .padding(16)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(
            Color.white,
            in: RoundedRectangle(cornerRadius: 12)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .strokeBorder(
                    hovered
                        ? Color.blue.opacity(0.45)
                        : LedgerStyle.border,
                    lineWidth: 1
                )
        )
        .shadow(
            color: .black.opacity(hovered ? 0.06 : 0.025),
            radius: hovered ? 8 : 3,
            y: 2
        )
        .onHover {
            hovered = $0
        }
    }

    // 卡片中的单据标题：单据类型 ｜ 单号
    private func billTitle(_ bill: Bill) -> String {
        let number = bill.number.trimmingCharacters(
            in: .whitespacesAndNewlines
        )

        return "\(bill.typeName) ｜ \(number.isEmpty ? "未填写单号" : number)"
    }

    private func cardBill(_ bill: Bill) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                Text(billTitle(bill))
                    .font(.system(size: 12, weight: .medium))
                    .lineLimit(1)
                    .truncationMode(.tail)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .help(billTitle(bill))

                Text(bill.status.rawValue)
                    .font(.system(size: 10))
                    .foregroundColor(bill.status.color)
                    .fixedSize(horizontal: true, vertical: false)
            }

            HStack(spacing: 4) {
                Text(uiMoney(bill.expected))
                    .font(
                        .system(
                            size: 15,
                            weight: .semibold,
                            design: .rounded
                        )
                    )
                    .foregroundColor(bill.status.color)

                Spacer(minLength: 2)

                Text("已到 \(uiMoney(bill.actual))")
                    .font(.system(size: 10))
                    .foregroundColor(.secondary)
            }
            .monospacedDigit()
            .lineLimit(1)
            .minimumScaleFactor(0.65)
        }
        .frame(height: 43)
    }
}
