import SwiftUI
import ReimburseCore

private enum DetailAction: String, Identifiable {
    case edit, receipt
    var id: String { rawValue }
}
struct TripDetail: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) private var dismiss
    let trip: Trip
    @State private var action: DetailAction?
    @State private var deleting = false
    @State private var showNote = false
    @State private var error: String?
    private var current: Trip { store.trips.first { $0.id == trip.id } ?? trip }
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("报销详情").font(.title2.bold())
                Spacer()
                Button { dismiss() } label: { Image(systemName: "xmark").foregroundColor(.secondary) }
                    .buttonStyle(.plain).keyboardShortcut(.cancelAction)
            }.padding(22)
            Divider()
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    parentRow
                    HStack {
                        Text("关联单据").font(.headline)
                        Text("\(current.bills.count) 张").font(.caption).foregroundColor(.secondary)
                        Spacer()
                        Text("应收 \(uiMoney(current.expected))  ·  已到账 \(uiMoney(current.actual))  ·  未到账 \(uiMoney(current.outstanding))")
                            .font(.caption).foregroundColor(.secondary).monospacedDigit()
                    }
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], alignment: .leading, spacing: 16) {
                        ForEach(current.sortedBills) { bill in DocumentCard(bill: bill) }
                    }
                }.padding(22)
            }.background(LedgerStyle.canvas)
            Divider()
            HStack {
                Button("删除记录", role: .destructive) { deleting = true }.buttonStyle(.plain).foregroundColor(.red)
                Spacer()
                Button("编辑记录") { action = .edit }.controlSize(.large)
                Button { action = .receipt } label: { Label("更新到账", systemImage: "arrow.down.circle") }
                    .buttonStyle(.borderedProminent).controlSize(.large)
            }.padding(20)
        }.frame(width: 1060, height: 720).background(Color.white)
            .sheet(item: $action) { value in
                switch value {
                case .edit: TripEditor(trip: current).environmentObject(store)
                case .receipt: ReceiptEditor(trip: current).environmentObject(store)
                }
            }
            .alert("删除这条报销记录？", isPresented: $deleting) {
                Button("取消", role: .cancel) {}
                Button("删除", role: .destructive) {
                    do { try store.delete(current); dismiss() }
                    catch { self.error = error.localizedDescription }
                }
            } message: { Text("将一并删除所有关联单据。此操作无法撤销。") }
            .alert("操作未完成", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("知道了") { error = nil }
            } message: { Text(error ?? "") }
    }
    private var parentRow: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack(spacing: 22) {
                Label(current.location, systemImage: "mappin.and.ellipse").font(.system(size: 20, weight: .semibold))
                Text(current.dateRange).font(.subheadline).foregroundColor(.secondary)
                Text("\(current.dayCount) 天").font(.caption).foregroundColor(.secondary)
                Spacer()
                StatusPill(text: current.sent ? "已寄出" : "未寄出", color: current.sent ? .blue : .gray)
                if current.allPaid { StatusPill(text: "全部到账", color: .green) }
            }
            if !current.note.isEmpty {
                DisclosureGroup("备注", isExpanded: $showNote) {
                    Text(current.note).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading).padding(.top, 6)
                }.font(.caption).foregroundColor(.secondary)
            }
        }.padding(20).background(Color.white, in: RoundedRectangle(cornerRadius: 12))
    }
}
struct DocumentCard: View {
    let bill: Bill
    @State private var showNote = false
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            HStack {
                Label(bill.typeName, systemImage: "doc.text").font(.headline)
                Spacer()
                StatusPill(text: bill.status.rawValue, color: bill.status.color)
            }
            Text("单号  \(bill.number.isEmpty ? "—" : bill.number)").font(.subheadline).foregroundColor(.secondary).textSelection(.enabled)
            Divider().opacity(0.5)
            HStack(spacing: 18) {
                amount("应收金额", bill.expected, LedgerStyle.ink)
                amount("到账金额", bill.actual, .green)
                amount("未到账", bill.outstanding, .orange)
            }
            if !bill.note.isEmpty {
                DisclosureGroup("单据备注", isExpanded: $showNote) {
                    Text(bill.note).textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading).padding(.top, 6)
                }.font(.caption).foregroundColor(.secondary)
            }
        }.padding(20).frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white, in: RoundedRectangle(cornerRadius: 12))
            .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(LedgerStyle.border, lineWidth: 1))
    }
    private func amount(_ title: String, _ value: Int64, _ color: Color) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(title).font(.caption).foregroundColor(.secondary)
            Text(uiMoney(value)).font(.system(size: 20, weight: .semibold, design: .rounded)).foregroundColor(color)
                .monospacedDigit().lineLimit(1).minimumScaleFactor(0.55)
        }.frame(maxWidth: .infinity, alignment: .leading)
    }
}
struct ReceiptEditor: View {
    @EnvironmentObject var store: Store
    @Environment(\.dismiss) private var dismiss
    let trip: Trip
    @State private var documents: [BillDraft]
    @State private var error: String?
    @State private var discard = false
    init(trip: Trip) {
        self.trip = trip; _documents = State(initialValue: trip.bills.map { BillDraft($0) })
    }
    private var dirty: Bool { documents != trip.bills.map { BillDraft($0) } }
    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            Text("更新到账金额").font(.title2.bold())
            Text("填写每张单据的累计实收金额，例如先到 50 元、再到 30 元，此处填 80 元。")
                .font(.subheadline).foregroundColor(.secondary)
            ScrollView {
                VStack(spacing: 16) {
                    ForEach($documents) { $document in
                        HStack {
                            VStack(alignment: .leading, spacing: 5) {
                                Text(document.kind == .other ? document.customType : document.kind.rawValue).font(.headline)
                                Text("单号 \(document.number.isEmpty ? "—" : document.number) · 应收 ¥\(document.expected)").font(.caption).foregroundColor(.secondary)
                            }
                            Spacer()
                            TextField("累计到账（元）", text: $document.actual).textFieldStyle(.roundedBorder).frame(width: 160)
                        }.padding(14).background(LedgerStyle.canvas, in: RoundedRectangle(cornerRadius: 8))
                    }
                }
            }
            HStack {
                Spacer()
                Button("取消") { if dirty { discard = true } else { dismiss() } }.keyboardShortcut(.cancelAction)
                Button("保存到账") { save() }.buttonStyle(.borderedProminent).keyboardShortcut(.defaultAction)
            }
        }.padding(24).frame(width: 650, height: 470).interactiveDismissDisabled(dirty)
            .alert("请检查到账金额", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("知道了") { error = nil }
            } message: { Text(error ?? "") }
            .alert("放弃未保存的到账修改？", isPresented: $discard) {
                Button("继续编辑", role: .cancel) {}
                Button("放弃", role: .destructive) { dismiss() }
            }
    }
    private func save() {
        do {
            guard var latest = store.trips.first(where: { $0.id == trip.id }) else { throw RuleError("报销记录已不存在。") }
            for draft in documents {
                guard let index = latest.bills.firstIndex(where: { $0.id == draft.id }) else { throw RuleError("单据已变更，请重新打开。") }
                latest.bills[index].actual = try Money.parse(draft.actual)
            }
            try store.save(latest); dismiss()
        } catch { self.error = error.localizedDescription }
    }
}
