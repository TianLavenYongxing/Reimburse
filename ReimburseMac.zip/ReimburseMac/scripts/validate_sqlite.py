"""Checks the actual SQL against a new empty SQLite database; no historical data."""
from pathlib import Path
import re
import sqlite3
source = (Path(__file__).resolve().parents[1] / 'Sources/ReimburseCore/Database.swift').read_text()
schema, upsert, insert_document = re.findall(r'"""(.*?)"""', source, re.S)
db = sqlite3.connect(':memory:')
db.execute('PRAGMA foreign_keys=ON')
db.executescript(schema)
assert {r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")} == {'reimbursement','document'}
assert db.execute('SELECT count(*) FROM reimbursement').fetchone()==(0,)
assert db.execute('SELECT count(*) FROM document').fetchone()==(0,)
with db:
    db.execute(upsert,('new','成都',1766966400,1766966400,1,'出差'))
    db.execute(insert_document,('n1','new','差旅报销单','','xx01',20000,0,'火车',0,0))
    db.execute(insert_document,('n2','new','补贴申请单','','xx02',10000,0,'差旅补贴',0,1))
assert db.execute('SELECT sum(expected),sum(actual),sum(max(0,expected-actual)) FROM document').fetchone()==(30000,0,30000)
try:
    with db:
        db.execute(upsert,('new','不应写入',1,2,0,''))
        db.execute(insert_document,('n1','new','其他','重复','',1,0,'',1,3))
except sqlite3.IntegrityError:pass
else:raise AssertionError('Missing uniqueness constraint')
assert db.execute('SELECT location FROM reimbursement').fetchone()==('成都',)
with db:db.execute('DELETE FROM reimbursement WHERE id="new"')
assert db.execute('SELECT count(*) FROM document').fetchone()==(0,)
assert not db.execute('PRAGMA foreign_key_check').fetchall()
assert 'ReimbursementRecords/records.sqlite' in source
assert 'FROM trip' not in source and 'CREATE TABLE trip' not in source
print('PASS: empty independent database, exactly two business tables, totals, rollback, cascading delete, no legacy SQL.')
