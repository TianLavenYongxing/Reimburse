import XCTest
@testable import ReimburseCore

final class ReimburseTests: XCTestCase {
    func example() -> Trip {
        var record = Trip(); record.location = "成都"; record.sent = true
        record.start = Calendar.current.date(from: DateComponents(year: 2025, month: 12, day: 29))!
        record.end = record.start
        record.bills[0].number = "xx01"; record.bills[0].expected = 20000; record.bills[0].note = "火车"
        record.bills[1].number = "xx02"; record.bills[1].note = "差旅补贴"
        record.updateAutomaticAllowances()
        return record
    }
    func testNewDatabaseStartsEmpty() throws {
        let database = try AppDatabase()
        XCTAssertTrue(try database.fetch().isEmpty)
    }
    func testUserExample() throws {
        let record = example(); try record.validate()
        XCTAssertEqual(record.dayCount, 1)
        XCTAssertEqual(record.expected, 30000)
        XCTAssertEqual(record.actual, 0)
        XCTAssertEqual(record.outstanding, 30000)
        XCTAssertTrue(record.bills.allSatisfy { $0.status == .waiting })
    }
    func testStatusesIndependentOfMailing() {
        var record = example(); record.sent = false
        XCTAssertEqual(record.bills[0].status, .waiting)
        record.bills[0].actual = 5000
        XCTAssertEqual(record.bills[0].status, .partial)
        record.bills[0].actual = 20000
        XCTAssertEqual(record.bills[0].status, .paid)
        record.bills[0].actual = 30000
        XCTAssertEqual(record.bills[0].status, .paid)
        XCTAssertEqual(record.outstanding, 10000)
        XCTAssertFalse(record.allPaid)
    }
    func testFilterAndDeduplicatedTotals() {
        var record = example()
        record.bills[0].actual = 5000
        XCTAssertTrue(TripFilter.waiting.matches(record))
        XCTAssertTrue(TripFilter.partial.matches(record))
        XCTAssertFalse(TripFilter.allPaid.matches(record))
        XCTAssertFalse(TripFilter.unsent.matches(record))
        let total = Summary([record,record])
        XCTAssertEqual(total.expected,30000); XCTAssertEqual(total.actual,5000); XCTAssertEqual(total.outstanding,25000)
        record.bills[0].actual = 20000; record.bills[1].actual = 10000
        XCTAssertTrue(TripFilter.allPaid.matches(record))
    }
    func testCardPriorityAndStableOrder() {
        var record = example()
        var third = Bill(kind: .daily); third.expected = 10000; third.actual = 10000
        var fourth = Bill(kind: .other); fourth.customType = "采购报销单"; fourth.expected = 10000; fourth.actual = 5000
        record.bills.insert(third, at: 0); record.bills.append(fourth)
        XCTAssertEqual(record.sortedBills.map(\.status), [.waiting,.waiting,.partial,.paid])
        XCTAssertEqual(record.sortedBills[0].number,"xx01")
    }
    func testAutomaticAndManualAllowance() {
        var record = example()
        record.end = Calendar.current.date(byAdding: .day, value: 2, to: record.start)!
        record.updateAutomaticAllowances()
        XCTAssertEqual(record.bills[1].expected,30000)
        record.bills[1].manualAmount = true; record.bills[1].expected = 35000
        record.end = Calendar.current.date(byAdding: .day, value: 5, to: record.start)!
        record.updateAutomaticAllowances(); XCTAssertEqual(record.bills[1].expected,35000)
        record.bills[1].manualAmount = false
        record.updateAutomaticAllowances(); XCTAssertEqual(record.bills[1].expected,60000)
    }
    func testRequiredFields() {
        var record = example(); record.bills[0].number = ""
        XCTAssertThrowsError(try record.validate())
        record.sent = false; XCTAssertNoThrow(try record.validate())
        record.bills = []; XCTAssertThrowsError(try record.validate())
        var other = Bill(kind: .other); XCTAssertThrowsError(try other.validate())
        other.customType = "招待费"; XCTAssertNoThrow(try other.validate())
        other.actual = -1; XCTAssertThrowsError(try other.validate())
    }
    func testMoneyPrecision() throws {
        XCTAssertEqual(try Money.parse("0.01"),1)
        XCTAssertEqual(try Money.parse("12.3"),1230)
        for value in ["", "-1", "1.234", "1e3", "1000000000"] { XCTAssertThrowsError(try Money.parse(value)) }
    }
    func testVariableDocumentPersistenceBackupAndDelete() throws {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: directory) }
        let url = directory.appendingPathComponent("db.sqlite")
        let database = try AppDatabase(url: url)
        var record = example()
        var other = Bill(kind: .other); other.customType = "培训报销"; other.number = "xx03"; other.expected = 12345; other.actual = 10000
        record.bills.append(other)
        record.bills[1].manualAmount = true
        try database.save(record)
        XCTAssertEqual(try AppDatabase(url: url).fetch(), [record])
        record.bills.removeFirst(); try database.save(record)
        XCTAssertEqual(try database.fetch(), [record])
        let backup = directory.appendingPathComponent("backup.sqlite")
        try database.backup(to: backup)
        XCTAssertEqual(try AppDatabase(url: backup).fetch(), [record])
        try database.delete(record.id); XCTAssertTrue(try database.fetch().isEmpty)
    }
    func testTransactionRollsBackOnDocumentConflict() throws {
        let db = try AppDatabase()
        let first = example(); try db.save(first)
        var second = example(); second.location = "上海"
        // A child ID belonging to another parent must not leave half a new record.
        second.bills[0].id = first.bills[0].id
        XCTAssertThrowsError(try db.save(second))
        XCTAssertEqual(try db.fetch(), [first])
    }
}
