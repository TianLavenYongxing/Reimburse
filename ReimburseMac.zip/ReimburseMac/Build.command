#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
exec > >(tee "$PWD/build.log") 2>&1
trap 'printf "\n构建失败。完整日志已保存到工程内的 build.log。按回车关闭。\n"; read -r _ || true' ERR
if [[ "$(uname -s)" != Darwin ]]; then
  echo "请在 Mac 上运行此脚本。"; exit 1
fi
if ! xcrun --find swift >/dev/null 2>&1; then
  echo "请先运行 xcode-select --install 安装 Apple 命令行工具，再重新运行。"; exit 1
fi
printf '\n工具链信息：\n'
xcrun swift --version
printf '\n正在解析依赖（GRDB 6.29.3），首次运行需要联网…\n'
swift package resolve
if xcrun --find xctest >/dev/null 2>&1; then
  printf '\n正在执行测试…\n'
  swift test
else
  printf '\n未检测到 XCTest 测试运行器：本次未执行单元测试，继续构建应用。\n'
fi
printf '\n正在构建本机版本…\n'
swift build -c release
BIN_DIR="$(swift build -c release --show-bin-path)"
APP="$PWD/dist/报销记录.app"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$BIN_DIR/ReimburseMac" "$APP/Contents/MacOS/ReimburseMac"
# Swift Package resource bundles (including GRDB privacy resources) must travel with the executable.
for resource in "$BIN_DIR"/*.bundle; do
  if [[ -d "$resource" ]]; then
    cp -R "$resource" "$APP/Contents/Resources/"
    cp -R "$resource" "$APP/Contents/MacOS/"
  fi
done
cp "$PWD/scripts/Info.plist" "$APP/Contents/Info.plist"
cp "$PWD/scripts/AppIcon.icns" "$APP/Contents/Resources/AppIcon.icns"
codesign --force --deep --sign - "$APP"
printf '\n完成：%s\n可将此 app 拖入“应用程序”，之后直接双击使用。\n' "$APP"
open -R "$APP"
open "$APP"
