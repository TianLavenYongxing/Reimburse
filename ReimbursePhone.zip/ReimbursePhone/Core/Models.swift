import Foundation

public struct RuleError: LocalizedError {
    public let message: String
    public init(_ message: String) { self.message = message }
    public var errorDescription: String? { message }
}

public enum Money {
    // Limit individual amounts to ¥999,999,999.99; never parse via Double.
    public static func parse(_ input: String) throws -> Int64 {
        let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard text.range(of: #"^[0-9]{1,9}(\.[0-9]{1,2})?$"#, options: .regularExpression) != nil else {
            throw RuleError("金额请填写非负数字，最多两位小数，最高 999,999,999.99 元。")
        }
        let parts = text.split(separator: ".")
        let fraction = parts.count == 2 ? String(parts[1]) : ""
        return Int64(parts[0])! * 100 + (Int64(fraction.padding(toLength: 2, withPad: "0", startingAt: 0)) ?? 0)
    }
    public static func plain(_ cents: Int64) -> String { "\(cents / 100)." + String(format: "%02lld", cents % 100) }
    public static func display(_ cents: Int64) -> String { "¥" + plain(cents) }
}

// UI state is derived from amounts; mailing belongs exclusively to the parent.
public enum BillStatus: String, CaseIterable, Codable {
    case waiting = "待到账", partial = "部分到账", paid = "已到账"
    public var priority: Int {
        switch self { case .waiting: return 0; case .partial: return 1; case .paid: return 2 }
    }
}
public enum BillKind: String, CaseIterable, Codable {
    case daily = "日常报销单", travel = "差旅报销单", allowance = "补贴申请单", other = "其他"
}
public struct Bill: Identifiable, Codable, Equatable {
    public var id = UUID().uuidString
    public var kind: BillKind
    public var customType = ""
    public var number = ""
    public var expected: Int64 = 0
    public var actual: Int64 = 0
    public var note = ""
    public var manualAmount = false
    public init(kind: BillKind) { self.kind = kind }
    public var typeName: String { kind == .other ? customType : kind.rawValue }
    public var outstanding: Int64 { max(0, expected - actual) }
    public var status: BillStatus {
        if actual >= expected { return .paid }
        return actual > 0 ? .partial : .waiting
    }
    public func validate() throws {
        guard (0...99_999_999_999).contains(expected), (0...99_999_999_999).contains(actual) else {
            throw RuleError("应收和到账金额须为非负数，且不超过 999,999,999.99 元。")
        }
        if kind == .other && customType.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            throw RuleError("选择“其他”时，请填写单据类型名称。")
        }
    }
}
public struct Trip: Identifiable, Codable, Equatable {
    public var id = UUID().uuidString
    public var location = ""
    public var start = Date()
    public var end = Date()
    public var sent = false
    public var note = ""
    public var bills = [Bill(kind: .travel), Bill(kind: .allowance)]
    public init() {}
    public var name: String { "\(location) · \(dateRange)" }
    public var dateRange: String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "yyyy/MM/dd"
        formatter.timeZone = Self.businessCalendar.timeZone
        return "\(formatter.string(from: start)) – \(formatter.string(from: end))"
    }
    public static var businessCalendar: Calendar {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(identifier: "Asia/Shanghai")!
        return calendar
    }
    public var dayCount: Int {
        let calendar = Self.businessCalendar
        let first = calendar.startOfDay(for: start), last = calendar.startOfDay(for: end)
        guard last >= first else { return 0 }
        return (calendar.dateComponents([.day], from: first, to: last).day ?? 0) + 1
    }
    public var calculatedAllowance: Int64 { Int64(dayCount) * 10_000 }
    public mutating func updateAutomaticAllowances() {
        for index in bills.indices where bills[index].kind == .allowance && !bills[index].manualAmount {
            bills[index].expected = calculatedAllowance
        }
    }
    public var allPaid: Bool { !bills.isEmpty && bills.allSatisfy { $0.status == .paid } }
    public var expected: Int64 { bills.reduce(0) { $0 + $1.expected } }
    public var actual: Int64 { bills.reduce(0) { $0 + $1.actual } }
    public var outstanding: Int64 { bills.reduce(0) { $0 + $1.outstanding } }
    // Equal-status documents keep their user-defined order.
    public var sortedBills: [Bill] {
        bills.enumerated().sorted {
            $0.element.status.priority == $1.element.status.priority
                ? $0.offset < $1.offset
                : $0.element.status.priority < $1.element.status.priority
        }.map(\.element)
    }
    public func validate() throws {
        guard !location.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { throw RuleError("请填写地点。") }
        guard dayCount > 0 else { throw RuleError("结束日期不能早于开始日期。") }
        guard !bills.isEmpty else { throw RuleError("至少添加一张单据。") }
        guard Set(bills.map(\.id)).count == bills.count else { throw RuleError("单据标识重复。") }
        for bill in bills {
            try bill.validate()
            if sent && bill.number.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                throw RuleError("\(bill.typeName)：已寄出的记录必须填写单号。")
            }
        }
    }
}
public enum TripFilter: String, CaseIterable, Identifiable {
    case all = "全部", unsent = "未寄出", waiting = "待到账", partial = "部分到账", allPaid = "全部到账"
    public var id: String { rawValue }
    public func matches(_ trip: Trip) -> Bool {
        switch self {
        case .all: return true
        case .unsent: return !trip.sent
        case .waiting: return trip.bills.contains { $0.status == .waiting }
        case .partial: return trip.bills.contains { $0.status == .partial }
        case .allPaid: return trip.allPaid
        }
    }
}
public struct Summary {
    public let expected: Int64
    public let actual: Int64
    public let outstanding: Int64
    public init(_ trips: [Trip]) {
        let unique = Dictionary(trips.map { ($0.id, $0) }, uniquingKeysWith: { a, _ in a }).values
        expected = unique.reduce(0) { $0 + $1.expected }
        actual = unique.reduce(0) { $0 + $1.actual }
        outstanding = unique.reduce(0) { $0 + $1.outstanding }
    }
}
