import Foundation
import GRDB

// One CloudKit record per reimbursement aggregate. Parent and bills arrive atomically.
// Deletions remain as tombstones, so an offline device cannot resurrect an old record.
struct SyncEnvelope: Codable, Equatable, Identifiable {
    var id: String
    var trip: Trip?
    var revision = UUID().uuidString
    var schemaVersion = 1
    func encoded() throws -> Data {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys]
        let data = try encoder.encode(self)
        guard data.count < 700_000 else { throw RuleError("这条记录过大，请减少备注或拆分单据。") }
        return data
    }
    static func decode(_ data: Data) throws -> Self {
        let value = try JSONDecoder().decode(Self.self, from: data)
        guard value.schemaVersion == 1 else { throw RuleError("云端数据版本较新，请更新 App。") }
        if let trip = value.trip {
            guard trip.id == value.id else { throw RuleError("同步记录标识不一致。") }
            try trip.validate()
        }
        return value
    }
}
struct SyncEntry {
    let envelope: SyncEnvelope
    let baseRevision: String?
    let serverFields: Data?
    let dirty: Bool
    let conflict: SyncEnvelope?
    init(_ row: Row) throws {
        envelope = try SyncEnvelope.decode(row["payload"])
        baseRevision = row["baseRevision"]
        serverFields = row["serverFields"]
        dirty = row["dirty"]
        let data: Data? = row["conflict"]
        conflict = try data.map { try SyncEnvelope.decode($0) }
    }
}
struct SyncConflict: Identifiable {
    let local: SyncEnvelope
    let remote: SyncEnvelope
    var id: String { local.id }
}
extension AppDatabase {
    func entry(_ id: String) throws -> SyncEntry? {
        try queue.read { db in
            try Row.fetchOne(db, sql: "SELECT * FROM sync_entry WHERE id=?", arguments: [id]).map(SyncEntry.init)
        }
    }
    func pendingIDs() throws -> [String] {
        try queue.read { try String.fetchAll($0, sql: "SELECT id FROM sync_entry WHERE dirty=1 AND conflict IS NULL ORDER BY id") }
    }
    func conflicts() throws -> [SyncConflict] {
        try queue.read { db in
            try Row.fetchAll(db, sql: "SELECT * FROM sync_entry WHERE conflict IS NOT NULL").map {
                let e = try SyncEntry($0)
                return SyncConflict(local: e.envelope, remote: e.conflict!)
            }
        }
    }
    func setting(_ key: String) throws -> Data? {
        try queue.read { try Data.fetchOne($0, sql: "SELECT value FROM sync_setting WHERE key=?", arguments: [key]) }
    }
    func setSetting(_ key: String, _ value: Data?) throws {
        try queue.write { db in
            if let value {
                try db.execute(sql: "INSERT INTO sync_setting(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", arguments: [key,value])
            } else {
                try db.execute(sql: "DELETE FROM sync_setting WHERE key=?", arguments: [key])
            }
        }
    }
    private static func materialize(_ value: SyncEnvelope, in db: Database) throws {
        if let trip = value.trip { try writeTrip(trip, in: db) }
        else { try db.execute(sql: "DELETE FROM reimbursement WHERE id=?", arguments: [value.id]) }
    }
    // Return true when the incoming revision requires explicit user resolution.
    @discardableResult
    func receive(_ remote: SyncEnvelope, fields: Data?) throws -> Bool {
        let payload = try remote.encoded()
        return try queue.write { db in
            if let row = try Row.fetchOne(db, sql: "SELECT * FROM sync_entry WHERE id=?", arguments: [remote.id]) {
                let local = try SyncEntry(row)
                if local.dirty && local.envelope.revision != remote.revision {
                    if local.baseRevision != remote.revision {
                        try db.execute(sql: "UPDATE sync_entry SET conflict=?,serverFields=?,baseRevision=? WHERE id=?", arguments: [payload,fields,remote.revision,remote.id])
                        return true
                    }
                    // Our unsent local edit was based on this server revision.
                    try db.execute(sql: "UPDATE sync_entry SET serverFields=? WHERE id=?", arguments: [fields,remote.id])
                    return local.conflict != nil
                }
            }
            try Self.materialize(remote, in: db)
            try db.execute(sql: """
                INSERT INTO sync_entry(id,payload,revision,baseRevision,serverFields,dirty) VALUES(?,?,?,?,?,0)
                ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,revision=excluded.revision,
                    baseRevision=excluded.baseRevision,serverFields=excluded.serverFields,dirty=0,conflict=NULL
                """, arguments: [remote.id,payload,remote.revision,remote.revision,fields])
            return false
        }
    }
    // A newer local edit may occur while an older revision is in flight.
    func acknowledge(_ remote: SyncEnvelope, fields: Data) throws {
        try queue.write { db in
            try db.execute(sql: """
                UPDATE sync_entry SET serverFields=?,baseRevision=?,
                    dirty=CASE WHEN revision=? THEN 0 ELSE 1 END WHERE id=?
                """, arguments: [fields,remote.revision,remote.revision,remote.id])
        }
    }
    func resolve(_ id: String, useLocal: Bool) throws {
        try queue.write { db in
            guard let row = try Row.fetchOne(db, sql: "SELECT * FROM sync_entry WHERE id=?", arguments: [id]) else { return }
            let e = try SyncEntry(row)
            guard let remote = e.conflict else { return }
            var chosen = useLocal ? e.envelope : remote
            if useLocal { chosen.revision = UUID().uuidString }
            try Self.materialize(chosen, in: db)
            try db.execute(sql: "UPDATE sync_entry SET payload=?,revision=?,baseRevision=?,dirty=?,conflict=NULL WHERE id=?", arguments: [try chosen.encoded(),chosen.revision,remote.revision,useLocal,id])
        }
    }
}
