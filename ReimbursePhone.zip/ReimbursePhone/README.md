# 报销记录 · iPhone 15 Pro / Mac 同步版

这是完整 SwiftUI 原生工程，不是网页套壳。基于你上传的最新版报销模型重新适配手机。
包含 iPhone App、配套 Mac App、SQLite/GRDB 数据层、CloudKit 同步代码和图标资源。

**交付状态：源代码、工程配置、图标和安装说明齐全；当前制作环境没有 Xcode / Apple SDK，未执行 iOS 或 macOS 编译，也未执行真机 CloudKit 联调。已进行 Swift 语法解析、工程引用、图标/plist 与 SQLite SQL 检查。不要把这些检查理解为真机测试通过。**

## 1. 最快运行：先体验本地版

1. 在 Mac 上解压本文件夹。
2. 用完整 Xcode 打开 **ReimbursePhone.xcodeproj**，不要打开 Package.swift（那是数据层测试入口）。建议使用你的 Swift 6.1.2 对应的 Xcode 16.4 或能够支持手机所装 iOS 的更高版本。
3. 顶部 Scheme 选择 **ReimbursePhone**，运行设备选择 **iPhone 15 Pro 模拟器**。没有模拟器时，在 Xcode Settings → Components 中安装 iOS Simulator。
4. 等待 Swift Package 解析 GRDB **6.29.3**，按 **⌘R**。
5. 默认无示例数据；点击右上角 + 开始使用。

本地版无需开启 iCloud，也不要求付费开发者资格。首次解析依赖需要联网。
最低系统：iOS 17。iPhone 15 Pro 可用；布局跟随可用宽度，不写死像素尺寸。支持竖屏、横屏、深浅色。

## 2. 安装到你的 iPhone 15 Pro

1. 使用数据线连接 Mac 与 iPhone，并在手机上选择“信任此电脑”。
2. Xcode → Settings → Accounts 登录 Apple 账户。
3. 打开 **Config/Settings.xcconfig**，把 `APP_IDENTIFIER_PREFIX` 改为你独有的前缀，例如 `com.laven.reimburse`（示例不保证全球未被占用）。
4. 选择项目 → Targets → ReimbursePhone → Signing & Capabilities，勾选 Automatically manage signing，Team 选择自己的团队。也可以在 xcconfig 的 DEVELOPMENT_TEAM 填入 Team ID。
5. 手机开启 设置 → 隐私与安全性 → 开发者模式，按系统提示重启确认。
6. Xcode 顶部设备选你的 iPhone，按 ⌘R。首次可能需要下载匹配设备的调试支持。

免费 Personal Team 可用于本地功能开发安装，但签名有效期及能力受限。CloudKit 必须使用支持该能力的 Apple Developer Program 团队。
这不是已签名 IPA；没有你的开发者签名，无法提供直接点开安装的通用 iPhone 安装包。

## 3. 已实现功能

- 首页应收 / 已到账 / 未到账汇总，按当前筛选和搜索范围统计；每条记录只算一次。
- 全部、未寄出、待到账、部分到账、全部到账筛选。
- 按出差开始月份倒序分组；iPhone 单列卡片；Mac 配套版四列。
- 卡片显示地点、日期、单据数、寄出状态；最多展示两张单据，待到账优先。
- 单据标题为“单据类型 ｜ 单号”；空单号显示“未填写单号”。
- 新增、编辑、删除主记录；任意添加日常 / 差旅 / 补贴 / 自定义单据。
- 两类备注默认折叠。已寄出的主记录要求每张子单据填写单号。
- 差旅补贴 = 含首尾的天数 × 100 元；手动修改后停止跟随日期，可恢复自动计算。
- 详情页可更新每张单据的累计到账金额，一键填入足额到账金额。
- 状态由应收与累计到账推导；0/0 算已到账，超额到账不抵消其他单据未到账金额。
- 金额以整数“分”存储和计算；无浮点货币误差。
- 日期统一按北京时间处理，避免跨时区导致补贴天数变化。
- 本地 SQLite 持久化、JSON 导出（此版不含 JSON 恢复导入）。
- 编辑期间如果记录已被同步修改，保存会提示重新打开，不直接覆盖新内容。

## 4. 开启 iCloud 自动同步（需要配置一次）

### 4.1 Xcode 配置

使用 Apple Developer Program 团队。**两个 Target 使用同一个 Team、同一个 CloudKit Container，但 Bundle Identifier 不同。**

分别对 ReimbursePhone 和 ReimburseMacCloud：

1. Signing & Capabilities → + Capability → iCloud，选择 CloudKit。
2. 创建或选择同一个容器，例如 `iCloud.com.laven.reimburse`。
3. 添加 Push Notifications。iPhone 的 Info.plist 已包含 remote-notification 后台模式。
4. 项目提供 Config/iOS.entitlements 和 Config/macOS.entitlements。若 Xcode 自动创建其他 entitlements 文件，请确保 Build Settings → Code Signing Entitlements 最终指向对应的提供文件，或把同样内容合并到 Xcode 生成的文件。

编辑 Config/Settings.xcconfig：

```xcconfig
APP_IDENTIFIER_PREFIX = com.laven.reimburse
DEVELOPMENT_TEAM = 你的TeamID
CLOUD_SYNC_CONFIGURED = YES
CLOUD_CONTAINER_IDENTIFIER = iCloud.com.laven.reimburse
CLOUD_ENTITLEMENTS_IOS = Config/iOS.entitlements
CLOUD_ENTITLEMENTS_MACOS = Config/macOS.entitlements
```

不要把“你的TeamID”原样保留；填入实际 ID。以上两处标识须与你在开发者账户创建的内容完全一致。

### 4.2 两端运行

1. 在同一个 Apple/iCloud 账户下运行两端 App。
2. 在 App 的“设置”中打开 iCloud 自动同步，确认将本地记录上传。
3. iPhone 新增一条记录，再在 Mac 点击“立即同步”。
4. Mac 更新到账金额，再在 iPhone 下拉刷新或点击“立即同步”。

Mac 必须使用本工程里的 **ReimburseMacCloud** Scheme。你之前的 GRDB-only Mac App 没有同步协议，不能自动接入此容器。
配套 Mac 最低 macOS 14。其数据目录与旧版隔离，不迁移旧数据，符合从零开始的要求。
开启 Mac sandbox 后也会使用沙盒下的 Application Support；请在录入正式数据前决定好签名/沙盒配置，避免看见不同数据目录而误认为丢失。

### 4.3 CloudKit 数据结构和环境

私有数据库；Custom Zone：`ReimbursementsV1`。
Record Type：`Reimbursement`，两个字段：

| 字段 | CloudKit 类型 | 用途 |
|---|---|---|
| payload | Bytes | 一条报销主记录及其全部子单据，JSON 编码 |
| revision | String | 每次修改的唯一版本 UUID |

开发模式下首次保存会建立 schema。发布 TestFlight / App Store 前，在 CloudKit Console 将 schema 部署到 Production；开发环境数据不会自动复制到生产环境。两端需要使用同一环境才能互相看到记录。
本版本使用 zone change 同步，不依赖业务字段查询索引。

### 4.4 同步行为和边界

- CKSyncEngine 自动安排上传、拉取和重试；App 前台每 45 秒额外请求一次同步，也支持手动刷新。
- 系统后台调度不保证秒级或即时送达；被强制退出的 App 不承诺后台更新。
- 本地保存与待上传记录在同一个 SQLite 事务中提交。
- 一条主记录和全部子单据作为同步整体，避免收取到半条记录。两端同时编辑同一条主记录（即使修改不同子单据）会保留两个版本，在设置中核对选择，不做金额自动相加。
- 删除使用持久删除标记，防止离线设备把旧数据重新上传回来；这一版不自动清理删除标记。
- 每条同步记录编码后限制在 700 KB 以下，超限会提示拆分。
- 本机数据库首次开启同步时绑定账户。退出/切换账户时暂停，不删除本机内容，也不自动上传给新账户；切回原账户可以恢复。此版未提供多账户切换或转移数据功能。
- 不支持在 CloudKit Console 手工删除业务记录/Zone 后的自动恢复；遇到这类外部修改会暂停同步并保留本机副本。
- 关闭同步不删除云端数据。本地功能继续使用。

## 5. 工程目录

| 路径 | 作用 |
|---|---|
| ReimbursePhone.xcodeproj | 可直接打开的双 Target Xcode 工程 |
| App/App.swift | 入口、数据 Store、导航与前台重试 |
| App/Dashboard.swift | 手机首页、筛选、月份卡片 |
| App/Editor.swift | 新增编辑、单据表单、自动补贴 |
| App/Detail.swift | 详情与累计到账更新 |
| App/Settings.swift | 同步设置、导出、冲突核对 |
| App/CloudSync.swift | CKSyncEngine 集成和账户检查 |
| App/Components.swift | 状态标记、金额行和卡片组件 |
| Core/Models.swift | 金额、日期、单据与筛选规则 |
| Core/Database.swift | GRDB 主表/子表与数据库迁移 |
| Core/SyncPersistence.swift | 同步待办、版本、删除标记和冲突持久化 |
| Config | 标识、签名参数、Info.plist 和 entitlements |
| Resources | iPhone / Mac 图标及隐私声明 |
| Tests | 核心业务与同步持久化 XCTest |
| scripts/Check.command | 在 Mac 上编译两个平台并运行测试 |

首次启动空库，后续正常保留记录，不会每次启动清空。
本地位置：App 的 Application Support / ReimburseCloudV1 / records.sqlite。

## 6. 在你的 Mac 上验证

双击 scripts/Check.command，或终端执行：

```bash
bash scripts/Check.command
```

脚本使用完整 Xcode（不是单独 Command Line Tools），编译通用 iOS 模拟器目标和 Mac 本地模式，再运行核心 XCTest。日志在 verification.log。
也可在 Xcode 选中 iPhone 15 Pro 模拟器直接运行。真机测试清单：

1. 成都 2025/12/29–2025/12/29，xx01 应收 200 元、xx02 自动补贴 100 元：合计 300，到账 0。
2. 改为三天：补贴 300。手动改成 280，再改日期：保持 280。恢复自动后随日期变化。
3. 将 200 元单据累计到账填 50：部分到账。填 200：已到账。
4. 未寄出允许空单号；开启已寄出后，空单号禁止保存。
5. 退出重开，检查所有记录保留。
6. 两台设备在线新增/更新/删除；再断网分别修改同一条记录，联网后检查冲突核对。
7. 上传期间继续编辑，确认新修改仍在待同步列表中。
8. 退出/切换 iCloud 账户，确认停止同步并保留本机数据。

官方参考：
- https://developer.apple.com/documentation/cloudkit/cksyncengine-5sie5
- https://github.com/apple/sample-cloudkit-sync-engine
- https://github.com/groue/GRDB.swift/tree/v6.29.3
