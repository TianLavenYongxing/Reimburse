import XCTest
@testable import ReimburseCore

final class ReimburseTests: XCTestCase {
    func example() -> Trip {
        var trip = Trip()
        trip.location = "成都"
        trip.start = Trip.businessCalendar.date(from: DateComponents(year: 2025, month: 12, day: 29))!
        trip.end = trip.start
        trip.sent = true
        trip.bills[0].number = "xx01"; trip.bills[0].expected = 20_000
        trip.bills[1].number = "xx02"
        trip.updateAutomaticAllowances()
        return trip
    }
    func testExampleAndPersistence() throws {
        let db = try AppDatabase()
        XCTAssertTrue(try db.fetch().isEmpty)
        let trip = example()
        try db.save(trip)
        XCTAssertEqual(try db.fetch(), [trip])
        XCTAssertEqual(trip.expected, 30_000)
        XCTAssertEqual(trip.outstanding, 30_000)
        XCTAssertEqual(try db.pendingIDs(), [trip.id])
    }
    func testInclusiveAllowanceAndManualOverride() {
        var trip = example()
        trip.end = Trip.businessCalendar.date(byAdding: .day, value: 2, to: trip.start)!
        trip.updateAutomaticAllowances()
        XCTAssertEqual(trip.dayCount, 3)
        XCTAssertEqual(trip.bills[1].expected, 30_000)
        trip.bills[1].manualAmount = true
        trip.bills[1].expected = 28_000
        trip.end = Trip.businessCalendar.date(byAdding: .day, value: 1, to: trip.end)!
        trip.updateAutomaticAllowances()
        XCTAssertEqual(trip.bills[1].expected, 28_000)
    }
    func testFiltersAndSummaryDoNotDoubleCount() {
        var trip = example()
        trip.bills[0].actual = 25_000
        trip.bills[1].actual = 2_000
        XCTAssertEqual(trip.bills[0].status, .paid)
        XCTAssertEqual(trip.bills[1].status, .partial)
        XCTAssertTrue(TripFilter.partial.matches(trip))
        XCTAssertFalse(TripFilter.allPaid.matches(trip))
        XCTAssertEqual(trip.sortedBills.first?.id, trip.bills[1].id)
        let s = Summary([trip, trip])
        XCTAssertEqual(s.expected, 30_000)
        XCTAssertEqual(s.actual, 27_000)
        XCTAssertEqual(s.outstanding, 8_000)
    }
    func testRequiredFieldsAndMoney() throws {
        XCTAssertEqual(try Money.parse("12.30"), 1_230)
        for text in ["", "-1", "12.345", "nan", "1e6"] { XCTAssertThrowsError(try Money.parse(text)) }
        var trip = example()
        trip.bills[0].number = ""
        XCTAssertThrowsError(try trip.validate())
        trip.sent = false
        XCTAssertNoThrow(try trip.validate())
        trip.end = Trip.businessCalendar.date(byAdding: .day, value: -1, to: trip.start)!
        XCTAssertThrowsError(try trip.validate())
    }
    func testOlderUploadAckKeepsNewerEditPending() throws {
        let db = try AppDatabase()
        var trip = example()
        try db.save(trip)
        let old = try XCTUnwrap(db.entry(trip.id)).envelope
        trip.note = "修改发生在上传过程中"
        try db.save(trip)
        try db.acknowledge(old, fields: Data([1]))
        XCTAssertEqual(try db.pendingIDs(), [trip.id])
        XCTAssertEqual(try db.fetch().first?.note, trip.note)
        let entry = try XCTUnwrap(db.entry(trip.id))
        XCTAssertEqual(entry.baseRevision, old.revision)
    }
    func testConflictPreservesBothVersions() throws {
        let a = try AppDatabase(), b = try AppDatabase()
        let initial = SyncEnvelope(id: example().id, trip: nil)
        var trip = example()
        trip.id = initial.id
        let base = SyncEnvelope(id: trip.id, trip: trip)
        try a.receive(base, fields: nil); try b.receive(base, fields: nil)
        var left = trip; left.bills[0].actual = 5_000
        var right = trip; right.bills[0].actual = 8_000
        try a.save(left); try b.save(right)
        let remote = try XCTUnwrap(b.entry(trip.id)).envelope
        XCTAssertTrue(try a.receive(remote, fields: nil))
        XCTAssertTrue(try a.pendingIDs().isEmpty)
        XCTAssertEqual(try a.fetch().first?.bills[0].actual, 5_000)
        XCTAssertEqual(try a.conflicts().first?.remote.trip?.bills[0].actual, 8_000)
        try a.resolve(trip.id, useLocal: false)
        XCTAssertEqual(try a.fetch().first?.bills[0].actual, 8_000)
        XCTAssertTrue(try a.conflicts().isEmpty)
    }
    func testDeletionTombstoneAndOfflineConflict() throws {
        let db = try AppDatabase()
        let trip = example()
        let base = SyncEnvelope(id: trip.id, trip: trip)
        try db.receive(base, fields: nil)
        try db.delete(trip.id)
        XCTAssertTrue(try db.fetch().isEmpty)
        XCTAssertNil(try db.entry(trip.id)?.envelope.trip)
        var changed = trip; changed.note = "另一设备离线修改"
        let remote = SyncEnvelope(id: trip.id, trip: changed)
        XCTAssertTrue(try db.receive(remote, fields: nil))
        try db.resolve(trip.id, useLocal: true)
        XCTAssertTrue(try db.fetch().isEmpty)
        XCTAssertEqual(try db.pendingIDs(), [trip.id])
    }
    func testParentAndOutboxRollbackTogether() throws {
        let db = try AppDatabase()
        let first = example()
        try db.save(first)
        var second = example()
        second.bills[0].id = first.bills[0].id
        XCTAssertThrowsError(try db.save(second))
        XCTAssertNil(try db.entry(second.id))
        XCTAssertEqual(try db.fetch(), [first])
    }
    func testReopenRetainsPendingChanges() throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        defer { try? FileManager.default.removeItem(at: folder) }
        let url = folder.appendingPathComponent("test.sqlite")
        let trip = example()
        do { let db = try AppDatabase(url: url); try db.save(trip) }
        let reopened = try AppDatabase(url: url)
        XCTAssertEqual(try reopened.fetch(), [trip])
        XCTAssertEqual(try reopened.pendingIDs(), [trip.id])
    }
}
