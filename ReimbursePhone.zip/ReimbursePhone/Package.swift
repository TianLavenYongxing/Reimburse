// swift-tools-version: 5.9
import PackageDescription
let package = Package(
    name: "ReimbursePhoneCore",
    platforms: [.iOS(.v17), .macOS(.v14)],
    products: [.library(name: "ReimburseCore", targets: ["ReimburseCore"])],
    dependencies: [.package(url: "https://github.com/groue/GRDB.swift.git", exact: "6.29.3")],
    targets: [
        .target(name: "ReimburseCore", dependencies: [.product(name: "GRDB", package: "GRDB.swift")], path: "Core"),
        .testTarget(name: "ReimburseCoreTests", dependencies: ["ReimburseCore"], path: "Tests")
    ]
)
