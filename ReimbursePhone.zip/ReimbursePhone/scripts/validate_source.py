"""Source/resource/actual SQL checks. Does not substitute for xcodebuild or XCTest."""
from pathlib import Path
import json, plistlib, sqlite3, re, xml.etree.ElementTree as ET
ROOT=Path(__file__).resolve().parents[1]
for p in (ROOT/'Config').glob('*'):
    if p.suffix in ['.plist','.entitlements']: plistlib.loads(p.read_bytes())
for p in (ROOT/'Resources').rglob('Contents.json'):
    obj=json.loads(p.read_text())
    for item in obj.get('images',[]): assert (p.parent/item['filename']).is_file()
for p in (ROOT/'ReimbursePhone.xcodeproj').rglob('*.xcscheme'): ET.parse(p)
source=(ROOT/'Core/Database.swift').read_text()
blocks=re.findall(r'"""(.*?)"""',source,re.S)
def sql(fragment): return next(s for s in blocks if fragment in s)
db=sqlite3.connect(':memory:')
db.execute('PRAGMA foreign_keys=ON')
db.executescript(sql('CREATE TABLE reimbursement'))
db.executescript(sql('CREATE TABLE sync_entry'))
parent=sql('INSERT INTO reimbursement')
child=sql('INSERT INTO document')
outbox=sql('INSERT INTO sync_entry')
with db:
    db.execute(parent,('t1','成都',0,0,1,''))
    for i,kind,amount in [('b1','差旅报销单',20000),('b2','补贴申请单',10000)]:
        db.execute(child,(i,'t1',kind,'','xx'+i,amount,0,'',0,0))
    db.execute(outbox,('t1',b'payload','r1'))
assert db.execute('SELECT SUM(expected),SUM(actual),SUM(MAX(0,expected-actual)) FROM document').fetchone()==(30000,0,30000)
try:
    with db:
        db.execute(parent,('t2','上海',0,0,0,''))
        db.execute(outbox,('t2',b'bad','r2'))
        db.execute(child,('b1','t2','差旅报销单','','',100,0,'',0,0))
except sqlite3.IntegrityError: pass
else: raise AssertionError('duplicate ID should fail')
assert db.execute("SELECT count(*) FROM reimbursement WHERE id='t2'").fetchone()[0]==0
assert db.execute("SELECT count(*) FROM sync_entry WHERE id='t2'").fetchone()[0]==0
with db: db.execute("DELETE FROM reimbursement WHERE id='t1'")
assert db.execute('SELECT count(*) FROM document').fetchone()[0]==0
assert db.execute('SELECT count(*) FROM sync_entry').fetchone()[0]==1
sync=(ROOT/'Core/SyncPersistence.swift').read_text()
ack=next(s for s in re.findall(r'"""(.*?)"""',sync,re.S) if 'dirty=CASE' in s)
with db:
    db.execute('UPDATE sync_entry SET revision=?,dirty=1 WHERE id=?',('r2','t1'))
    db.execute(ack,(b'fields','r1','r1','t1'))
assert db.execute('SELECT dirty,baseRevision FROM sync_entry').fetchone()==(1,'r1')
print('PASS: plist, icon references, schemes, actual SQLite schemas, totals, transaction rollback, cascade, in-flight revision acknowledgement.')
