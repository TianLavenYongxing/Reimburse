#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
exec > >(tee "$PWD/verification.log") 2>&1
trap 'echo "验证失败，请查看 verification.log。"' ERR
if [[ "$(uname -s)" != "Darwin" ]]; then
    echo "请在安装了完整 Xcode 的 Mac 上运行。"
    exit 1
fi
xcodebuild -version
xcrun swift --version
xcodebuild -project ReimbursePhone.xcodeproj -scheme ReimbursePhone \
    -configuration Debug -destination 'generic/platform=iOS Simulator' \
    -derivedDataPath .verification-build CODE_SIGNING_ALLOWED=NO \
    CLOUD_SYNC_CONFIGURED=NO CODE_SIGN_ENTITLEMENTS= build
xcodebuild -project ReimbursePhone.xcodeproj -scheme ReimburseMacCloud \
    -configuration Debug -destination 'platform=macOS' \
    -derivedDataPath .verification-build CODE_SIGNING_ALLOWED=NO \
    CLOUD_SYNC_CONFIGURED=NO CODE_SIGN_ENTITLEMENTS= build
swift test
echo "编译与核心测试完成。iCloud 双设备同步还需在你的账户下验证。"
