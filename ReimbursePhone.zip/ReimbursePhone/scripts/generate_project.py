#!/usr/bin/env python3
"""Generate a checked-in Xcode project without XcodeGen or CocoaPods."""
from pathlib import Path
import hashlib, json, plistlib
ROOT = Path(__file__).resolve().parents[1]
objects = {}
def uid(key): return hashlib.sha1(key.encode()).hexdigest()[:24].upper()
def add(key, isa, **values):
    i=uid(key); objects[i]={'isa':isa,**values}; return i
def ref(path, kind):
    return add('ref:'+path,'PBXFileReference',lastKnownFileType=kind,path=path,sourceTree='<group>')
def dump(value, depth=0):
    if isinstance(value,dict): return '{\n'+''.join('  '*(depth+1)+json.dumps(str(k))+ ' = '+dump(v,depth+1)+';\n' for k,v in value.items())+'  '*depth+'}'
    if isinstance(value,list): return '(\n'+''.join('  '*(depth+1)+dump(v,depth+1)+',\n' for v in value)+'  '*depth+')'
    return json.dumps(str(value),ensure_ascii=False)
sources=sorted(str(p.relative_to(ROOT)) for folder in ['App','Core'] for p in (ROOT/folder).glob('*.swift'))
source_refs=[ref(p,'sourcecode.swift') for p in sources]
configref=ref('Config/Settings.xcconfig','text.xcconfig')
extra=[ref('Config/iOS-Info.plist','text.plist.xml'),ref('Config/macOS-Info.plist','text.plist.xml'),ref('Config/iOS.entitlements','text.plist.entitlements'),ref('Config/macOS.entitlements','text.plist.entitlements'),ref('README.md','net.daringfireball.markdown')]
package=add('GRDB','XCRemoteSwiftPackageReference',repositoryURL='https://github.com/groue/GRDB.swift.git',requirement={'kind':'exactVersion','version':'6.29.3'})
products=[]; targets=[]; resource_refs=[]
for platform,name in [('iOS','ReimbursePhone'),('macOS','ReimburseMacCloud')]:
    product=add('product:'+name,'PBXFileReference',explicitFileType='wrapper.application',includeInIndex=0,path=name+'.app',sourceTree='BUILT_PRODUCTS_DIR'); products.append(product)
    dep=add('dep:'+name,'XCSwiftPackageProductDependency',package=package,productName='GRDB')
    srcfiles=[add(name+':src:'+p,'PBXBuildFile',fileRef=r) for p,r in zip(sources,source_refs)]
    sourcephase=add(name+':sources','PBXSourcesBuildPhase',buildActionMask=2147483647,files=srcfiles,runOnlyForDeploymentPostprocessing=0)
    fw=add(name+':grdbbuild','PBXBuildFile',productRef=dep)
    fwphase=add(name+':frameworks','PBXFrameworksBuildPhase',buildActionMask=2147483647,files=[fw],runOnlyForDeploymentPostprocessing=0)
    asset=ref('Resources/'+platform+'/Assets.xcassets','folder.assetcatalog');resource_refs.append(asset)
    privacy=ref('Resources/PrivacyInfo.xcprivacy','text.xml')
    resourcefiles=[add(name+':assetbuild','PBXBuildFile',fileRef=asset),add(name+':privacy','PBXBuildFile',fileRef=privacy)]
    resphase=add(name+':resources','PBXResourcesBuildPhase',buildActionMask=2147483647,files=resourcefiles,runOnlyForDeploymentPostprocessing=0)
    configs=[]
    for mode in ['Debug','Release']:
        settings={
            'PRODUCT_NAME':'$(TARGET_NAME)','PRODUCT_BUNDLE_IDENTIFIER':'$(APP_IDENTIFIER_PREFIX).'+('phone' if platform=='iOS' else 'mac'),
            'INFOPLIST_FILE':f'Config/{platform}-Info.plist','GENERATE_INFOPLIST_FILE':'NO',
            'SWIFT_VERSION':'5.0','SWIFT_STRICT_CONCURRENCY':'minimal',
            'CODE_SIGN_STYLE':'Automatic','CODE_SIGN_ENTITLEMENTS':'$(CLOUD_ENTITLEMENTS_'+platform.upper()+')',
            'ASSETCATALOG_COMPILER_APPICON_NAME':'AppIcon','MARKETING_VERSION':'3.0','CURRENT_PROJECT_VERSION':'1',
            'APS_ENVIRONMENT':'development' if mode=='Debug' else 'production',
            'SWIFT_OPTIMIZATION_LEVEL':'-Onone' if mode=='Debug' else '-O',
            'SWIFT_ACTIVE_COMPILATION_CONDITIONS':'DEBUG' if mode=='Debug' else '',
            'ENABLE_PREVIEWS':'YES',
        }
        if platform=='iOS': settings.update(SDKROOT='iphoneos',SUPPORTED_PLATFORMS='iphoneos iphonesimulator',IPHONEOS_DEPLOYMENT_TARGET='17.0',TARGETED_DEVICE_FAMILY='1',SUPPORTS_MACCATALYST='NO')
        else: settings.update(SDKROOT='macosx',SUPPORTED_PLATFORMS='macosx',MACOSX_DEPLOYMENT_TARGET='14.0',ENABLE_HARDENED_RUNTIME='YES')
        configs.append(add(name+':'+mode,'XCBuildConfiguration',name=mode,baseConfigurationReference=configref,buildSettings=settings))
    cl=add(name+':configs','XCConfigurationList',buildConfigurations=configs,defaultConfigurationIsVisible=0,defaultConfigurationName='Release')
    target=add(name,'PBXNativeTarget',name=name,buildConfigurationList=cl,buildPhases=[sourcephase,fwphase,resphase],buildRules=[],dependencies=[],packageProductDependencies=[dep],productName=name,productReference=product,productType='com.apple.product-type.application'); targets.append(target)
    scheme=ROOT/'ReimbursePhone.xcodeproj/xcshareddata/xcschemes'/f'{name}.xcscheme';scheme.parent.mkdir(parents=True,exist_ok=True)
    scheme.write_text(f'''<?xml version="1.0" encoding="UTF-8"?>
<Scheme LastUpgradeVersion="1640" version="1.3">
<BuildAction parallelizeBuildables="YES" buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES" buildForProfiling="YES" buildForArchiving="YES" buildForAnalyzing="YES"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="{name}.app" BlueprintName="{name}" ReferencedContainer="container:ReimbursePhone.xcodeproj"/></BuildActionEntry></BuildActionEntries></BuildAction>
<LaunchAction buildConfiguration="Debug" selectedDebuggerIdentifier="Xcode.DebuggerFoundation.Debugger.LLDB" selectedLauncherIdentifier="Xcode.IDEFoundation.Launcher.LLDB" launchStyle="0" useCustomWorkingDirectory="NO" ignoresPersistentStateOnLaunch="NO" debugDocumentVersioning="YES" allowLocationSimulation="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="{name}.app" BlueprintName="{name}" ReferencedContainer="container:ReimbursePhone.xcodeproj"/></BuildableProductRunnable></LaunchAction>
<ProfileAction buildConfiguration="Release" shouldUseLaunchSchemeArgsEnv="YES" savedToolIdentifier="" useCustomWorkingDirectory="NO" debugDocumentVersioning="YES"><BuildableProductRunnable runnableDebuggingMode="0"><BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{target}" BuildableName="{name}.app" BlueprintName="{name}" ReferencedContainer="container:ReimbursePhone.xcodeproj"/></BuildableProductRunnable></ProfileAction>
<AnalyzeAction buildConfiguration="Debug"/><ArchiveAction buildConfiguration="Release" revealArchiveInOrganizer="YES"/>
</Scheme>''')
pg=add('Products','PBXGroup',children=products,name='Products',sourceTree='<group>')
main=add('main','PBXGroup',children=source_refs+resource_refs+[privacy,configref]+extra+[pg],sourceTree='<group>')
configs=[add('project:'+mode,'XCBuildConfiguration',name=mode,buildSettings={'CLANG_ENABLE_MODULES':'YES','CLANG_ENABLE_OBJC_ARC':'YES','SWIFT_VERSION':'5.0','DEBUG_INFORMATION_FORMAT':'dwarf' if mode=='Debug' else 'dwarf-with-dsym','ONLY_ACTIVE_ARCH':'YES' if mode=='Debug' else 'NO'}) for mode in ['Debug','Release']]
cl=add('projectconfigs','XCConfigurationList',buildConfigurations=configs,defaultConfigurationIsVisible=0,defaultConfigurationName='Release')
project=add('project','PBXProject',attributes={'BuildIndependentTargetsInParallel':'YES','LastUpgradeCheck':'1640'},buildConfigurationList=cl,compatibilityVersion='Xcode 14.0',developmentRegion='zh-Hans',hasScannedForEncodings=0,knownRegions=['zh-Hans','en','Base'],mainGroup=main,productRefGroup=pg,projectDirPath='',projectRoot='',targets=targets,packageReferences=[package])
(ROOT/'ReimbursePhone.xcodeproj/project.pbxproj').write_text('// !$*UTF8*$!\n'+dump({'archiveVersion':1,'classes':{},'objectVersion':56,'objects':objects,'rootObject':project})+'\n')
workspace=ROOT/'ReimbursePhone.xcodeproj/project.xcworkspace';workspace.mkdir(exist_ok=True)
(workspace/'contents.xcworkspacedata').write_text('<?xml version="1.0" encoding="UTF-8"?><Workspace version="1.0"><FileRef location="self:"></FileRef></Workspace>')
print('Generated Xcode project with',len(sources),'Swift files and two application targets.')
