# 交付验证记录

已在制作环境执行：

- 12 个 Swift 文件经 tree-sitter-swift 语法解析，无语法错误节点（不等同 Swift 编译器类型检查）。
- project.pbxproj 经 OpenStep plist 解析；70 个工程对象的源码、资源和产品引用已检查。
- 两个 Scheme XML、Info.plist、entitlements 和隐私声明格式检查。
- iPhone AppIcon 资源均为无透明通道 RGB 图像，图片文件引用检查通过。
- SQLite 直接执行源码中的建表和写入 SQL：金额合计、主子表事务回滚、级联删除和保留同步标记检查通过。
- 上传旧版本完成后，新版本仍保持 dirty 的 SQL 检查通过。
- Check.command 经 bash -n 检查。

未执行（缺少 Xcode / Apple SDK / 开发者账户）：

- iOS / macOS 编译、链接和运行。
- XCTest 执行。提供了 9 项测试，需在 Mac 上运行 swift test。
- iPhone 15 Pro 模拟器或真机界面、键盘、旋转、动态字体测试。
- CloudKit 容器创建、签名、推送和双设备端到端同步测试。

请按 README 在 Xcode 中运行；scripts/Check.command 可执行双平台本地编译和核心测试。
