import SwiftUI

struct TripDetailView: View {
    @EnvironmentObject private var store: LedgerStore
    @Environment(\.dismiss) private var dismiss
    let id: String
    @State private var editing = false
    @State private var deleting = false
    @State private var receiving: Bill?
    private var trip: Trip? { store.trips.first { $0.id == id } }
    private var columns: [GridItem] {
        #if os(macOS)
        [GridItem(.flexible()), GridItem(.flexible())]
        #else
        [GridItem(.flexible())]
        #endif
    }
    var body: some View {
        Group {
            if let trip {
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        VStack(alignment: .leading, spacing: 12) {
                            HStack {
                                Label(trip.location, systemImage: "mappin.circle.fill").font(.title2.bold())
                                Spacer()
                                Tag(title: trip.sent ? "已寄出" : "未寄出", color: trip.sent ? .blue : .gray)
                            }
                            Text(trip.dateRange).font(.subheadline).foregroundStyle(.secondary)
                            Text("\(trip.dayCount) 天 · \(trip.bills.count) 张单据").font(.caption).foregroundStyle(.secondary)
                            Divider()
                            MoneyLine(title: "应收合计", cents: trip.expected)
                            MoneyLine(title: "已到账", cents: trip.actual, color: .green)
                            MoneyLine(title: "未到账", cents: trip.outstanding, color: .orange)
                            if !trip.note.isEmpty {
                                DisclosureGroup("备注") { Text(trip.note).frame(maxWidth: .infinity, alignment: .leading).padding(.top, 8) }
                            }
                        }.ledgerCard()
                        Text("关联单据").font(.headline)
                        LazyVGrid(columns: columns, spacing: 16) {
                            ForEach(trip.sortedBills) { bill in
                                VStack(alignment: .leading, spacing: 16) {
                                    BillSummary(bill: bill)
                                    Divider()
                                    MoneyLine(title: "尚未到账", cents: bill.outstanding)
                                    if !bill.note.isEmpty {
                                        DisclosureGroup("单据备注") { Text(bill.note).frame(maxWidth: .infinity, alignment: .leading) }
                                    }
                                    Button { receiving = bill } label: {
                                        Label("更新到账金额", systemImage: "arrow.down.circle")
                                            .frame(maxWidth: .infinity)
                                    }.buttonStyle(.bordered)
                                }.ledgerCard()
                            }
                        }
                        Button("删除报销记录", role: .destructive) { deleting = true }
                            .frame(maxWidth: .infinity).padding(.top, 12)
                    }.padding(16)
                }.background(.background.secondary)
                .sheet(isPresented: $editing) { TripEditorView(original: trip) }
                .sheet(item: $receiving) { bill in ReceiptView(original: trip, bill: bill) }
                .confirmationDialog("删除这条报销及其全部单据？开启同步后，其他设备也会删除。", isPresented: $deleting, titleVisibility: .visible) {
                    Button("删除", role: .destructive) {
                        store.delete(trip)
                        if store.error == nil { dismiss() }
                    }
                }
            } else {
                ContentUnavailableView("记录已删除", systemImage: "doc.badge.minus")
            }
        }
        .navigationTitle("报销详情")
        #if os(iOS)
        .navigationBarTitleDisplayMode(.inline)
        #endif
        .toolbar { ToolbarItem(placement: .primaryAction) { Button("编辑") { editing = true }.disabled(trip == nil) } }
    }
}
struct ReceiptView: View {
    @EnvironmentObject private var store: LedgerStore
    @Environment(\.dismiss) private var dismiss
    let original: Trip
    let bill: Bill
    @State private var actual: String
    @State private var error: String?
    init(original: Trip, bill: Bill) {
        self.original = original; self.bill = bill
        _actual = State(initialValue: Money.plain(bill.actual))
    }
    var body: some View {
        NavigationStack {
            Form {
                Section(bill.typeName) {
                    LabeledContent("单号", value: bill.number.isEmpty ? "未填写" : bill.number)
                    MoneyLine(title: "应收金额", cents: bill.expected)
                }
                Section {
                    TextField("累计到账金额", text: $actual).amountKeyboard()
                    Button("填入足额到账金额") { actual = Money.plain(bill.expected) }
                } header: { Text("累计到账金额（元）") } footer: {
                    Text("填写至今实际到账的合计，保存后自动计算状态；不是本次新增金额。")
                }
            }.formStyle(.grouped)
            .navigationTitle("更新到账")
            #if os(iOS)
            .navigationBarTitleDisplayMode(.inline)
            #endif
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) { Button("保存") { save() } }
            }
            .alert("无法保存", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("知道了", role: .cancel) {}
            } message: { Text(error ?? "") }
        }
        .interactiveDismissDisabled(actual != Money.plain(bill.actual))
        #if os(macOS)
        .frame(width: 500, height: 380)
        #endif
    }
    private func save() {
        do {
            var trip = original
            guard let index = trip.bills.firstIndex(where: { $0.id == bill.id }) else { return }
            trip.bills[index].actual = try Money.parse(actual)
            try store.save(trip, original: original)
            dismiss()
        } catch { self.error = error.localizedDescription }
    }
}
