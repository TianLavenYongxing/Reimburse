import SwiftUI

struct SettingsView: View {
    @EnvironmentObject private var store: LedgerStore
    @ObservedObject var sync: CloudSync
    @State private var exporting = false
    @State private var backup: BackupDocument?
    @State private var connecting = false
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Toggle("iCloud 自动同步", isOn: Binding(get: { sync.enabled }, set: { value in
                        if value { connecting = true }
                        else { Task { await sync.setEnabled(false) } }
                    })).disabled(!CloudSync.configured)
                    Label(sync.status, systemImage: sync.busy ? "arrow.triangle.2.circlepath" : "icloud")
                        .font(.subheadline).foregroundStyle(.secondary)
                    if let date = sync.lastSync {
                        LabeledContent("最近同步") { Text(date, style: .time) }
                    }
                    Button {
                        Task { await sync.syncNow() }
                    } label: { Label("立即同步", systemImage: "arrow.clockwise") }
                        .disabled(!sync.enabled || sync.busy || !CloudSync.configured)
                } header: { Text("设备间同步") } footer: {
                    Text(CloudSync.configured
                         ? "同一 Apple 账户下的 iPhone 和配套 Mac 版共享记录。断网时继续本地保存；系统会在合适时机同步。"
                         : "当前是本地版，可以正常记账。启用 iCloud 需先在 Xcode 配置开发者签名、CloudKit 容器及 Config 文件，具体见工程内说明。")
                }
                if !store.conflicts.isEmpty {
                    Section("需要核对 · \(store.conflicts.count) 条") {
                        ForEach(store.conflicts) { conflict in
                            NavigationLink {
                                ConflictView(id: conflict.id)
                            } label: {
                                VStack(alignment: .leading, spacing: 5) {
                                    Text(conflict.local.trip?.location ?? conflict.remote.trip?.location ?? "已删除记录")
                                    Text("两端有不同修改，点击选择保留版本").font(.caption).foregroundStyle(.orange)
                                }
                            }
                        }
                    }
                }
                Section {
                    LabeledContent("报销记录", value: "\(store.trips.count) 条")
                    LabeledContent("关联单据", value: "\(store.trips.reduce(0) { $0 + $1.bills.count }) 张")
                    Button {
                        do { backup = try BackupDocument(trips: store.trips); exporting = true }
                        catch { store.error = error.localizedDescription }
                    } label: { Label("导出本机记录（JSON）", systemImage: "square.and.arrow.up") }
                } header: { Text("数据") } footer: {
                    Text("导出当前本机可见记录，不包含删除标记与冲突中的云端版本。同步与备份是不同功能。")
                }
                Section("关于") {
                    LabeledContent("报销记录", value: "3.0")
                    Text("SwiftUI · SQLite · GRDB · CloudKit").font(.footnote).foregroundStyle(.secondary)
                    Text("日期按北京时间处理，补贴包含首尾日期，默认 100 元 / 天。")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }.formStyle(.grouped)
            .navigationTitle("设置")
            .fileExporter(isPresented: $exporting, document: backup, contentType: .json, defaultFilename: "报销记录备份") { result in
                if case .failure(let error) = result { store.error = error.localizedDescription }
            }
            .confirmationDialog("将本机记录同步到当前 iCloud 账户？", isPresented: $connecting, titleVisibility: .visible) {
                Button("启用同步") { Task { await sync.setEnabled(true) } }
            } message: {
                Text("同步后，使用同一容器和账户的设备会共享记录。此本机数据库将绑定当前账户。")
            }
        }
    }
}
struct ConflictView: View {
    @EnvironmentObject private var store: LedgerStore
    @Environment(\.dismiss) private var dismiss
    let id: String
    @State private var choice: Bool?
    private var conflict: SyncConflict? { store.conflicts.first { $0.id == id } }
    var body: some View {
        ScrollView {
            if let conflict {
                VStack(alignment: .leading, spacing: 20) {
                    Text("同一条报销在两端都被修改。请核对单据和金额，再选择需要保留的版本。")
                        .font(.subheadline).foregroundStyle(.secondary)
                    version("本机版本", envelope: conflict.local)
                    version("iCloud 版本", envelope: conflict.remote)
                    Button("保留本机版本") { choice = true }.buttonStyle(.borderedProminent)
                    Button("使用 iCloud 版本") { choice = false }.buttonStyle(.bordered)
                    Text("选中的版本将用于后续同步；另一个版本将被替换。")
                        .font(.caption).foregroundStyle(.secondary)
                }.padding(16)
            } else { ContentUnavailableView("冲突已解决", systemImage: "checkmark.circle") }
        }
        .background(.background.secondary)
        .navigationTitle("核对冲突")
        .confirmationDialog("确认采用这个版本？", isPresented: Binding(get: { choice != nil }, set: { if !$0 { choice = nil } }), titleVisibility: .visible) {
            Button("确认") {
                guard let local = choice else { return }
                store.resolve(id, local: local)
                if store.error == nil { dismiss() }
                choice = nil
            }
        }
    }
    private func version(_ title: String, envelope: SyncEnvelope) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            Text(title).font(.headline)
            if let trip = envelope.trip {
                Text(trip.location).font(.title3.bold())
                Text(trip.dateRange).font(.caption)
                Text(trip.sent ? "已寄出" : "未寄出").font(.caption)
                if !trip.note.isEmpty { Text(trip.note).font(.subheadline) }
                ForEach(trip.bills) { bill in
                    Divider()
                    BillSummary(bill: bill)
                    if !bill.note.isEmpty { Text(bill.note).font(.caption) }
                    if bill.kind == .allowance { Text(bill.manualAmount ? "手动补贴金额" : "自动补贴金额").font(.caption) }
                }
            } else { Label("此版本已删除记录", systemImage: "trash").foregroundStyle(.red) }
        }.ledgerCard()
    }
}
