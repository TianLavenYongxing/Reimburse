import Foundation
import CloudKit
import Combine

@MainActor
final class CloudSync: ObservableObject, CKSyncEngineDelegate {
    @Published var status = "仅保存在本机"
    @Published var busy = false
    @Published var enabled = UserDefaults.standard.bool(forKey: "cloudSyncEnabled")
    @Published var lastSync: Date?
    var changed: (() -> Void)?
    let database: AppDatabase
    private var engine: CKSyncEngine?
    private var starting = false
    private var failed = false
    private let zoneID = CKRecordZone.ID(zoneName: "ReimbursementsV1")
    static var configured: Bool { (Bundle.main.object(forInfoDictionaryKey: "CloudSyncConfigured") as? String) == "YES" }
    private var container: CKContainer {
        CKContainer(identifier: Bundle.main.object(forInfoDictionaryKey: "CloudContainerIdentifier") as! String)
    }
    init(database: AppDatabase) { self.database = database }

    func start() async {
        guard enabled, Self.configured, engine == nil, !starting else { return }
        starting = true
        defer { starting = false }
        do {
            guard try await container.accountStatus() == .available else {
                throw RuleError("请在系统设置中登录 iCloud，并允许本 App 使用 iCloud。")
            }
            let user = try await container.userRecordID().recordName
            let identity = Data(user.utf8)
            if let bound = try database.setting("account"), bound != identity {
                throw RuleError("iCloud 账户已变化。为避免混入其他账户的数据，同步已暂停；请登录原账户。本机记录仍然保留。")
            }
            guard enabled else { return }
            try database.setSetting("account", identity)
            let state = try database.setting("engine").map {
                try JSONDecoder().decode(CKSyncEngine.State.Serialization.self, from: $0)
            }
            var config = CKSyncEngine.Configuration(database: container.privateCloudDatabase, stateSerialization: state, delegate: self)
            config.automaticallySync = true
            let newEngine = CKSyncEngine(config)
            engine = newEngine
            newEngine.state.add(pendingDatabaseChanges: [.saveZone(CKRecordZone(zoneID: zoneID))])
            try queuePending()
            status = "已连接 iCloud"
        } catch { status = error.localizedDescription }
    }
    func setEnabled(_ value: Bool) async {
        enabled = value
        UserDefaults.standard.set(value, forKey: "cloudSyncEnabled")
        if value {
            await syncNow()
        } else {
            let old = engine
            engine = nil
            await old?.cancelOperations()
            busy = false
            status = "仅保存在本机 · 云端数据保留"
        }
    }
    func localChanged() {
        do { try queuePending() }
        catch { stopForError(error) }
    }
    private func queuePending() throws {
        guard let engine else { return }
        let ids = try database.pendingIDs()
        engine.state.add(pendingRecordZoneChanges: ids.map { .saveRecord(CKRecord.ID(recordName: $0, zoneID: zoneID)) })
    }
    func syncNow() async {
        guard enabled else { return }
        guard Self.configured else { status = "此构建未配置 iCloud，请按工程说明配置签名与容器。"; return }
        await start()
        guard let engine, !busy else { return }
        busy = true
        failed = false
        status = "正在同步…"
        defer { busy = false; changed?() }
        do {
            try await engine.fetchChanges()
            guard self.engine === engine else { return }
            try queuePending()
            try await engine.sendChanges()
            if !failed {
                lastSync = Date()
                let conflicts = try database.conflicts().count
                let pending = try database.pendingIDs().count
                status = conflicts > 0 ? "有 \(conflicts) 条冲突待核对" : (pending > 0 ? "\(pending) 条修改待上传" : "已同步")
            }
        } catch { failed = true; status = "同步未完成：\(error.localizedDescription)" }
    }
    private func stopForError(_ error: Error) {
        failed = true
        status = "同步已暂停：\(error.localizedDescription)"
        let old = engine
        engine = nil
        Task { await old?.cancelOperations() }
    }
    nonisolated func handleEvent(_ event: CKSyncEngine.Event, syncEngine: CKSyncEngine) async {
        await process(event, engine: syncEngine)
    }
    private func process(_ event: CKSyncEngine.Event, engine current: CKSyncEngine) {
        guard engine === current else { return }
        do {
            switch event {
            case .stateUpdate(let update):
                try database.setSetting("engine", JSONEncoder().encode(update.stateSerialization))
            case .accountChange(let change):
                switch change.changeType {
                case .signIn: break
                case .signOut, .switchAccounts:
                    stopForError(RuleError("iCloud 账户已退出或切换。请使用原账户后重新同步；本机数据已保留。"))
                @unknown default: stopForError(RuleError("iCloud 账户状态发生变化，请重新连接。"))
                }
            case .fetchedRecordZoneChanges(let changes):
                for item in changes.modifications {
                    try receive(item.record, engine: current)
                }
                if changes.deletions.contains(where: { $0.recordID.zoneID == zoneID }) {
                    // This app uses tombstones, never raw CloudKit deletes.
                    throw RuleError("云端记录被外部删除。已保留本地副本，请核查 CloudKit 容器后重试。")
                }
                changed?()
            case .sentRecordZoneChanges(let changes):
                for record in changes.savedRecords {
                    let envelope = try decode(record)
                    try database.acknowledge(envelope, fields: archive(record))
                }
                for failure in changes.failedRecordSaves {
                    if failure.error.code == .serverRecordChanged, let server = failure.error.serverRecord {
                        try receive(server, engine: current)
                    } else {
                        failed = true
                        status = "待重试：\(failure.error.localizedDescription)"
                    }
                }
                // Only enqueue edits newer than a successful in-flight upload.
                // Do not continuously requeue permanent server failures within one send operation.
                for record in changes.savedRecords {
                    if let entry = try database.entry(record.recordID.recordName), entry.dirty, entry.conflict == nil {
                        current.state.add(pendingRecordZoneChanges: [.saveRecord(record.recordID)])
                    }
                }
                changed?()
            case .fetchedDatabaseChanges(let changes):
                if changes.deletions.contains(where: { $0.zoneID == zoneID }) {
                    throw RuleError("云端同步区域已被删除。同步暂停，本机数据保留。")
                }
            case .didFetchRecordZoneChanges(let result):
                if let error = result.error { failed = true; status = "同步未完成：\(error.localizedDescription)" }
            case .sentDatabaseChanges(let result):
                if !result.failedZoneSaves.isEmpty { failed = true; status = "无法创建云端同步区域，请检查 iCloud 权限或网络。" }
            case .didSendChanges:
                if !failed {
                    let count = try database.conflicts().count
                    status = count > 0 ? "有 \(count) 条冲突待核对" : "同步完成"
                    lastSync = Date()
                }
                changed?()
            default: break
            }
        } catch { stopForError(error) }
    }
    private func receive(_ record: CKRecord, engine: CKSyncEngine) throws {
        guard record.recordID.zoneID == zoneID, record.recordType == "Reimbursement" else { return }
        let incoming = try decode(record)
        let conflict = try database.receive(incoming, fields: archive(record))
        if conflict {
            engine.state.remove(pendingRecordZoneChanges: [.saveRecord(record.recordID)])
            status = "有冲突待核对，请打开设置"
        }
    }
    nonisolated func nextRecordZoneChangeBatch(_ context: CKSyncEngine.SendChangesContext, syncEngine: CKSyncEngine) async -> CKSyncEngine.RecordZoneChangeBatch? {
        let pending = syncEngine.state.pendingRecordZoneChanges.filter { context.options.scope.contains($0) }
        return await CKSyncEngine.RecordZoneChangeBatch(pendingChanges: pending) { id in
            await self.makeRecord(id, engine: syncEngine)
        }
    }
    private func makeRecord(_ id: CKRecord.ID, engine current: CKSyncEngine) -> CKRecord? {
        guard engine === current else { return nil }
        do {
            guard let entry = try database.entry(id.recordName), entry.dirty, entry.conflict == nil else {
                current.state.remove(pendingRecordZoneChanges: [.saveRecord(id)])
                return nil
            }
            let record: CKRecord
            if let data = entry.serverFields {
                let coder = try NSKeyedUnarchiver(forReadingFrom: data)
                coder.requiresSecureCoding = true
                defer { coder.finishDecoding() }
                guard let restored = CKRecord(coder: coder) else { throw RuleError("同步元数据无法读取。") }
                record = restored
            } else { record = CKRecord(recordType: "Reimbursement", recordID: id) }
            record["payload"] = try entry.envelope.encoded() as NSData
            record["revision"] = entry.envelope.revision as NSString
            return record
        } catch { stopForError(error); return nil }
    }
    private func archive(_ record: CKRecord) throws -> Data {
        let coder = NSKeyedArchiver(requiringSecureCoding: true)
        record.encodeSystemFields(with: coder)
        coder.finishEncoding()
        return coder.encodedData
    }
    private func decode(_ record: CKRecord) throws -> SyncEnvelope {
        guard let data = record["payload"] as? Data else { throw RuleError("云端记录缺少内容。") }
        let envelope = try SyncEnvelope.decode(data)
        guard envelope.id == record.recordID.recordName else { throw RuleError("云端记录 ID 不一致。") }
        return envelope
    }
}
