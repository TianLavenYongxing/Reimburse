import SwiftUI
#if os(iOS)
import UIKit
#endif

struct BillDraft: Identifiable, Equatable {
    var id: String
    var kind: BillKind
    var customType: String
    var number: String
    var expected: String
    var actual: String
    var note: String
    var manualAmount: Bool
    init(_ bill: Bill) {
        id = bill.id; kind = bill.kind; customType = bill.customType; number = bill.number
        expected = Money.plain(bill.expected); actual = Money.plain(bill.actual)
        note = bill.note; manualAmount = bill.manualAmount
    }
    func value() throws -> Bill {
        var bill = Bill(kind: kind)
        bill.id = id; bill.customType = customType.trimmingCharacters(in: .whitespacesAndNewlines)
        bill.number = number.trimmingCharacters(in: .whitespacesAndNewlines)
        bill.expected = try Money.parse(expected); bill.actual = try Money.parse(actual)
        bill.note = note; bill.manualAmount = manualAmount
        return bill
    }
}
struct TripEditorView: View {
    @EnvironmentObject private var store: LedgerStore
    @Environment(\.dismiss) private var dismiss
    let original: Trip?
    @State private var trip: Trip
    @State private var bills: [BillDraft]
    private let initial: Trip
    private let initialBills: [BillDraft]
    @State private var error: String?
    @State private var discarding = false
    @State private var removing: String?
    @State private var showNote = false

    init(original: Trip?) {
        self.original = original
        var value = original ?? Trip()
        if original == nil { value.updateAutomaticAllowances() }
        let drafts = value.bills.map(BillDraft.init)
        self.initial = value; self.initialBills = drafts
        _trip = State(initialValue: value)
        _bills = State(initialValue: drafts)
    }
    private var dirty: Bool { trip != initial || bills != initialBills }
    private var columns: [GridItem] {
        #if os(macOS)
        [GridItem(.flexible()), GridItem(.flexible())]
        #else
        [GridItem(.flexible())]
        #endif
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    parentFields
                    HStack {
                        Text("关联单据 · \(bills.count)").font(.headline)
                        Spacer()
                        Menu {
                            ForEach(BillKind.allCases, id: \.self) { kind in
                                Button(kind.rawValue) { add(kind) }
                            }
                        } label: { Label("添加", systemImage: "plus.circle") }
                    }
                    LazyVGrid(columns: columns, alignment: .leading, spacing: 16) {
                        ForEach($bills) { $bill in
                            BillForm(bill: $bill, days: trip.dayCount, sent: trip.sent) {
                                removing = bill.id
                            }
                        }
                    }
                    Text("金额以元为单位。补贴按首尾日期都包含计算，默认每天 100 元；手动修改后不再随日期变化。")
                        .font(.footnote).foregroundStyle(.secondary)
                }.padding(16).padding(.bottom, 24)
            }
            .background(.background.secondary)
            .navigationTitle(original == nil ? "新增报销" : "编辑报销")
            #if os(iOS)
            .navigationBarTitleDisplayMode(.inline)
            #endif
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("取消") { if dirty { discarding = true } else { dismiss() } }
                }
                ToolbarItem(placement: .confirmationAction) { Button("保存", action: save).fontWeight(.semibold) }
                #if os(iOS)
                ToolbarItemGroup(placement: .keyboard) {
                    Spacer()
                    Button("完成") { UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil) }
                }
                #endif
            }
            .onChange(of: trip.start) { _, _ in updateAllowance() }
            .onChange(of: trip.end) { _, _ in updateAllowance() }
            .alert("无法保存", isPresented: Binding(get: { error != nil }, set: { if !$0 { error = nil } })) {
                Button("知道了", role: .cancel) {}
            } message: { Text(error ?? "") }
            .confirmationDialog("放弃未保存的修改？", isPresented: $discarding, titleVisibility: .visible) {
                Button("放弃修改", role: .destructive) { dismiss() }
            }
            .confirmationDialog("移除这张单据？", isPresented: Binding(get: { removing != nil }, set: { if !$0 { removing = nil } }), titleVisibility: .visible) {
                Button("移除单据", role: .destructive) {
                    guard let id = removing else { return }
                    bills.removeAll { $0.id == id }; removing = nil
                }
            }
        }
        .interactiveDismissDisabled(dirty)
        #if os(macOS)
        .frame(minWidth: 850, minHeight: 700)
        #endif
    }
    private var parentFields: some View {
        VStack(alignment: .leading, spacing: 18) {
            Label("报销信息", systemImage: "mappin.and.ellipse").font(.headline)
            VStack(alignment: .leading, spacing: 8) {
                Text("地点").font(.subheadline).foregroundStyle(.secondary)
                TextField("例如：成都", text: $trip.location).textFieldStyle(.roundedBorder)
            }
            DatePicker("开始日期", selection: $trip.start, displayedComponents: .date)
            DatePicker("结束日期", selection: $trip.end, displayedComponents: .date)
            HStack {
                Text(trip.dayCount > 0 ? "共 \(trip.dayCount) 天（含首尾）" : "结束日期不能早于开始日期")
                    .font(.caption).foregroundStyle(trip.dayCount > 0 ? Color.secondary : Color.red)
                Spacer()
            }
            Divider()
            Toggle("单据已寄出", isOn: $trip.sent)
            DisclosureGroup("备注（选填）", isExpanded: $showNote) {
                TextField("填写报销备注", text: $trip.note, axis: .vertical)
                    .lineLimit(3...6).textFieldStyle(.roundedBorder).padding(.top, 8)
            }.font(.subheadline)
        }.ledgerCard()
    }
    private func add(_ kind: BillKind) {
        var bill = Bill(kind: kind)
        if kind == .allowance { bill.expected = trip.calculatedAllowance }
        bills.append(BillDraft(bill))
    }
    private func updateAllowance() {
        for index in bills.indices where bills[index].kind == .allowance && !bills[index].manualAmount {
            bills[index].expected = Money.plain(trip.calculatedAllowance)
        }
    }
    private func save() {
        do {
            updateAllowance()
            var value = trip
            value.location = value.location.trimmingCharacters(in: .whitespacesAndNewlines)
            value.bills = try bills.map { try $0.value() }
            try value.validate()
            try store.save(value, original: original)
            dismiss()
        } catch { self.error = error.localizedDescription }
    }
}
struct BillForm: View {
    @Binding var bill: BillDraft
    let days: Int
    let sent: Bool
    let remove: () -> Void
    @State private var showNote = false
    private var amount: Binding<String> {
        Binding(get: { bill.expected }, set: {
            bill.expected = $0
            if bill.kind == .allowance { bill.manualAmount = true }
        })
    }
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Image(systemName: bill.kind == .allowance ? "sun.max" : "doc.text").foregroundStyle(.blue)
                Text(bill.kind.rawValue).font(.headline)
                Spacer()
                Button(role: .destructive, action: remove) { Image(systemName: "trash") }
                    .buttonStyle(.borderless).accessibilityLabel("移除单据")
            }
            Picker("单据类型", selection: $bill.kind) {
                ForEach(BillKind.allCases, id: \.self) { Text($0.rawValue).tag($0) }
            }.pickerStyle(.menu)
            if bill.kind == .other {
                field("类型名称", placeholder: "手动填写单据类型", text: $bill.customType)
            }
            field(sent ? "单号（必填）" : "单号", placeholder: "例如：B26004081", text: $bill.number)
            VStack(alignment: .leading, spacing: 8) {
                Text("应收金额（元）").font(.caption).foregroundStyle(.secondary)
                TextField("0.00", text: amount).amountKeyboard().textFieldStyle(.roundedBorder)
            }
            VStack(alignment: .leading, spacing: 8) {
                Text("累计到账金额（元）").font(.caption).foregroundStyle(.secondary)
                TextField("0.00", text: $bill.actual).amountKeyboard().textFieldStyle(.roundedBorder)
            }
            if bill.kind == .allowance {
                VStack(alignment: .leading, spacing: 8) {
                    if bill.manualAmount {
                        Text("手动金额 · 修改日期不会覆盖").font(.caption).foregroundStyle(.secondary)
                        Button("恢复自动计算") { restoreAuto() }.font(.caption)
                    } else {
                        Label("\(days) 天 × 100 元 = \(days * 100) 元", systemImage: "sparkles")
                            .font(.caption).foregroundStyle(.blue)
                    }
                }
            }
            DisclosureGroup("备注（选填）", isExpanded: $showNote) {
                TextField("填写单据备注", text: $bill.note, axis: .vertical)
                    .lineLimit(2...5).textFieldStyle(.roundedBorder).padding(.top, 8)
            }.font(.subheadline)
        }
        .ledgerCard()
        .onChange(of: bill.kind) { _, kind in if kind == .allowance { restoreAuto() } }
    }
    private func restoreAuto() {
        bill.manualAmount = false
        bill.expected = Money.plain(Int64(days) * 10_000)
    }
    private func field(_ label: String, placeholder: String, text: Binding<String>) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(label).font(.caption).foregroundStyle(.secondary)
            TextField(placeholder, text: text).textFieldStyle(.roundedBorder)
        }
    }
}
