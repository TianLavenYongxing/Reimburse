import SwiftUI

struct DashboardView: View {
    @EnvironmentObject private var store: LedgerStore
    @State private var filter: TripFilter = .all
    @State private var search = ""
    @State private var adding = false
    private var visible: [Trip] {
        store.trips.filter { trip in
            let searchable = "\(trip.location) \(trip.dateRange) \(trip.bills.map(\.number).joined(separator: " "))"
            return filter.matches(trip) && (search.isEmpty || searchable.localizedCaseInsensitiveContains(search))
        }
    }
    private var months: [Date] { Array(grouped.keys).sorted(by: >) }
    private var grouped: [Date: [Trip]] {
        Dictionary(grouping: visible) {
            Trip.businessCalendar.date(from: Trip.businessCalendar.dateComponents([.year, .month], from: $0.start)) ?? $0.start
        }
    }
    private var columns: [GridItem] {
        #if os(macOS)
        Array(repeating: GridItem(.flexible(), spacing: 16, alignment: .top), count: 4)
        #else
        [GridItem(.flexible())]
        #endif
    }
    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 22) {
                    totals
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(TripFilter.allCases) { item in
                                Button { filter = item } label: {
                                    Text(item.rawValue).font(.subheadline.weight(.medium))
                                        .padding(.horizontal, 15).padding(.vertical, 10)
                                        .foregroundStyle(filter == item ? Color.white : Color.primary)
                                        .background(filter == item ? Color.blue : Palette.card, in: Capsule())
                                }.buttonStyle(.plain)
                            }
                        }
                    }
                    if visible.isEmpty {
                        ContentUnavailableView {
                            Label(store.trips.isEmpty ? "开始记录第一笔报销" : "没有匹配的记录", systemImage: "doc.text.magnifyingglass")
                        } description: {
                            Text(store.trips.isEmpty ? "把单据和到账进度放在一起，少一点惦记。" : "换个筛选条件，或清空搜索。")
                        } actions: {
                            if store.trips.isEmpty { Button("新增报销") { adding = true }.buttonStyle(.borderedProminent) }
                        }
                    }
                    ForEach(months, id: \.self) { month in
                        monthSection(month)
                    }
                }.padding(16).padding(.bottom, 20)
            }
            .background(.background.secondary)
            .navigationTitle("报销记录")
            .searchable(text: $search, prompt: "地点、日期或单号")
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button { adding = true } label: { Image(systemName: "plus.circle.fill").font(.title2) }
                        .accessibilityLabel("新增报销记录")
                }
            }
            .refreshable { await store.sync.syncNow() }
            .navigationDestination(for: String.self) { id in TripDetailView(id: id) }
            .sheet(isPresented: $adding) { TripEditorView(original: nil) }
        }
    }
    private var totals: some View {
        let value = Summary(visible)
        return VStack(alignment: .leading, spacing: 22) {
            HStack {
                Label("应收总金额", systemImage: "creditcard").font(.subheadline)
                Spacer()
                Text("\(visible.count) 条记录").font(.caption)
            }.foregroundStyle(.white.opacity(0.8))
            Text(Money.display(value.expected))
                .font(.system(size: 38, weight: .bold, design: .rounded))
                .monospacedDigit().lineLimit(1).minimumScaleFactor(0.5)
            HStack(alignment: .top) {
                totalItem("已到账", value.actual)
                Spacer()
                Rectangle().fill(.white.opacity(0.25)).frame(width: 1, height: 38)
                Spacer()
                totalItem("未到账", value.outstanding)
            }
        }
        .padding(24).foregroundStyle(.white)
        .background(LinearGradient(colors: [Color(red: 0.16, green: 0.40, blue: 0.91), Color(red: 0.13, green: 0.27, blue: 0.69)], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 26))
    }
    private func totalItem(_ title: String, _ amount: Int64) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.caption).foregroundStyle(.white.opacity(0.75))
            Text(Money.display(amount)).font(.headline).monospacedDigit().lineLimit(1).minimumScaleFactor(0.6)
        }
    }
    private func monthSection(_ month: Date) -> some View {
        let records = grouped[month] ?? []
        return VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text(month, format: .dateTime.year().month()).font(.headline)
                Spacer()
                Text("\(records.count) 条").font(.caption).foregroundStyle(.secondary)
            }.padding(.horizontal, 4)
            LazyVGrid(columns: columns, spacing: 14) {
                ForEach(records) { trip in
                    NavigationLink(value: trip.id) { TripCardView(trip: trip) }
                        .buttonStyle(.plain)
                }
            }
        }
    }
}
struct TripCardView: View {
    let trip: Trip
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text(trip.location).font(.title3.weight(.bold)).lineLimit(2)
                Spacer()
                Tag(title: trip.sent ? "已寄出" : "未寄出", color: trip.sent ? .blue : .gray)
            }
            Text(trip.dateRange).font(.caption).foregroundStyle(.secondary)
            HStack {
                Label("\(trip.bills.count) 张单据", systemImage: "doc.on.doc")
                Spacer()
                if trip.allPaid { Label("全部到账", systemImage: "checkmark.circle.fill").foregroundStyle(.green) }
            }.font(.caption)
            Divider()
            ForEach(Array(trip.sortedBills.prefix(2))) { bill in BillSummary(bill: bill) }
            HStack {
                Text(trip.bills.count > 2 ? "另有 \(trip.bills.count - 2) 张单据" : "查看详情")
                Spacer()
                Image(systemName: "chevron.right")
            }.font(.caption).foregroundStyle(.secondary)
        }.ledgerCard()
    }
}
