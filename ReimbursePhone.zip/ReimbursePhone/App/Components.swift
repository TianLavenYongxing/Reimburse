import SwiftUI

extension BillStatus {
    var color: Color {
        switch self { case .waiting: return .orange; case .partial: return .purple; case .paid: return .green }
    }
}
enum Palette {
    static let canvas = Color(red: 0.95, green: 0.96, blue: 0.98)
    static var card: Color {
        #if os(iOS)
        Color(uiColor: .secondarySystemGroupedBackground)
        #else
        Color(nsColor: .controlBackgroundColor)
        #endif
    }
}
struct Tag: View {
    let title: String
    let color: Color
    var body: some View {
        Text(title).font(.caption.weight(.medium))
            .padding(.horizontal, 9).padding(.vertical, 5)
            .foregroundStyle(color).background(color.opacity(0.10), in: Capsule())
            .fixedSize(horizontal: true, vertical: false)
    }
}
struct MoneyLine: View {
    let title: String
    let cents: Int64
    var color: Color = .primary
    var body: some View {
        HStack {
            Text(title).foregroundStyle(.secondary)
            Spacer(minLength: 8)
            Text(Money.display(cents)).fontWeight(.semibold).monospacedDigit().foregroundStyle(color)
        }
    }
}
extension View {
    func ledgerCard() -> some View {
        self.padding(18).frame(maxWidth: .infinity, alignment: .leading)
            .background(Palette.card, in: RoundedRectangle(cornerRadius: 20))
    }
    @ViewBuilder func amountKeyboard() -> some View {
        #if os(iOS)
        self.keyboardType(.decimalPad)
        #else
        self
        #endif
    }
}
struct BillSummary: View {
    let bill: Bill
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top) {
                Text("\(bill.typeName) ｜ \(bill.number.isEmpty ? "未填写单号" : bill.number)")
                    .font(.subheadline.weight(.medium)).lineLimit(2)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Tag(title: bill.status.rawValue, color: bill.status.color)
            }
            HStack(alignment: .firstTextBaseline) {
                Text(Money.display(bill.expected)).font(.title3.weight(.semibold)).foregroundStyle(bill.status.color)
                Spacer()
                Text("已到 \(Money.display(bill.actual))").font(.caption).foregroundStyle(.secondary)
            }.monospacedDigit()
            if bill.status == .partial {
                ProgressView(value: Double(bill.actual), total: Double(max(1, bill.expected))).tint(.purple)
                Text("\(Money.display(bill.actual)) / \(Money.display(bill.expected))")
                    .font(.caption2).foregroundStyle(.secondary)
            }
        }
    }
}
