import SwiftUI
import UniformTypeIdentifiers
#if os(iOS)
import UIKit
#else
import AppKit
#endif

@MainActor
final class LedgerStore: ObservableObject {
    @Published var trips: [Trip] = []
    @Published var conflicts: [SyncConflict] = []
    @Published var error: String?
    let database: AppDatabase
    let sync: CloudSync
    init(database: AppDatabase) {
        self.database = database
        self.sync = CloudSync(database: database)
        sync.changed = { [weak self] in self?.reload() }
        reload()
    }
    func reload() {
        do { trips = try database.fetch(); conflicts = try database.conflicts() }
        catch { self.error = error.localizedDescription }
    }
    func save(_ trip: Trip, original: Trip?) throws {
        if let original, trips.first(where: { $0.id == original.id }) != original {
            throw RuleError("这条记录已在其他窗口或设备更新。请关闭编辑页，查看最新内容后重新编辑。")
        }
        try database.save(trip)
        reload()
        sync.localChanged()
    }
    func delete(_ trip: Trip) {
        do { try database.delete(trip.id); reload(); sync.localChanged() }
        catch { self.error = error.localizedDescription }
    }
    func resolve(_ id: String, local: Bool) {
        do { try database.resolve(id, useLocal: local); reload(); sync.localChanged() }
        catch { self.error = error.localizedDescription }    }
}

@main
struct ReimburseApp: App {
    @StateObject private var bootstrap = Bootstrap()
    var body: some Scene {
        WindowGroup {
            if let store = bootstrap.store {
                RootView().environmentObject(store)
                    .environment(\.locale, Locale(identifier: "zh_CN"))
                    .environment(\.timeZone, TimeZone(identifier: "Asia/Shanghai")!)
                    .tint(.blue)
                    #if os(macOS)
                    .frame(minWidth: 900, minHeight: 680)
                    #endif
            } else {
                ContentUnavailableView {
                    Label("数据库无法打开", systemImage: "externaldrive.badge.exclamationmark")
                } description: { Text(bootstrap.failure ?? "未知错误") } actions: {
                    Button("重试") { bootstrap.open() }
                }
            }
        }
    }
}
@MainActor
final class Bootstrap: ObservableObject {
    @Published var store: LedgerStore?
    @Published var failure: String?
    init() { open() }
    func open() {
        do { store = LedgerStore(database: try AppDatabase.live()) }
        catch { failure = error.localizedDescription }
    }
}
struct RootView: View {
    @EnvironmentObject private var store: LedgerStore
    @Environment(\.scenePhase) private var scenePhase
    var body: some View {
        TabView {
            DashboardView()
                .tabItem { Label("报销", systemImage: "rectangle.stack") }
            SettingsView(sync: store.sync)
                .tabItem { Label("设置", systemImage: "gearshape") }
                .badge(store.conflicts.count)
        }
        .task(id: scenePhase) {
            guard scenePhase == .active else { return }
            if CloudSync.configured {
                #if os(iOS)
                UIApplication.shared.registerForRemoteNotifications()
                #else
                NSApplication.shared.registerForRemoteNotifications(matching: [])
                #endif
            }
            // Also retry when foregrounded: silent push delivery is not guaranteed.
            while !Task.isCancelled {
                await store.sync.syncNow()
                do { try await Task.sleep(for: .seconds(45)) } catch { break }
            }
        }
        .alert("操作未完成", isPresented: Binding(get: { store.error != nil }, set: { if !$0 { store.error = nil } })) {
            Button("知道了") { store.error = nil }
        } message: { Text(store.error ?? "") }
    }
}
struct BackupDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.json] }
    var data: Data
    init(trips: [Trip]) throws {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        data = try encoder.encode(trips)
    }
    init(configuration: ReadConfiguration) throws {
        data = configuration.file.regularFileContents ?? Data()
    }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        FileWrapper(regularFileWithContents: data)
    }
}
